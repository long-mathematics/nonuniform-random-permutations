# First-moment synthesis: collision-weighted gain, the two-sided bridge, and comparable cycle pairs

## Scope and provenance

This is a new derivation from the supplied summary of Claude's proposed upper-bound proof and the earlier working notes `thorp_boundary_weighted_comparison.md`, `thorp_birthday_scale.md`, and `thorp_entropy_audit_and_refinement.md`. The file `thorp_first_moment_upper.md` was not available, so this note is not an audit of that unseen document.

The proof below combines the existing entropy tail and middle-first bridge with a convexity estimate for open collisions. It sharpens the earlier one-cycle comparison. It also proves a two-cycle upper bound when the two lengths are comparable. It does not establish arbitrary-length two-cycle asymptotics, tilted decorrelation, or the full one-shuffle Erdos--Turan law. The finite checks verify specified ingredients, not the large-d asymptotics or external peer review.

Throughout, N=2^d, and

\[
T_f(x_1,\ldots,x_d)=(x_2,\ldots,x_d,x_1\oplus f(x_2,\ldots,x_d)),
\]

where all feedback values are independent fair bits. The initial root X is uniform and independent of f. Set

\[
Q_d(r)=r\mathbb EC_r=N\mathbb P(L_f(X)=r),\qquad
A_d(n)=\sum_{h\le n}Q_d(h).
\]

Logarithms used in entropy and the factor log_2 d are base two. Logarithms of permutation order are natural.

## 1. The resulting one-cycle estimate

Fix 0<beta<2/3 and put

\[
p_\beta=\frac{2}{2-3\beta},\qquad
\Pi_\beta(d)=C_\beta(d\log_2d)^{p_\beta}.
\]

For sufficiently large d, uniformly for d^4 <= r <= N^beta,

\[
\boxed{
1-10\frac{dr}{N}\le Q_d(r)
\le 1+C_\beta d(d\log_2d)^{p_\beta}\frac rN.
}\tag{T1}
\]

In particular Q_d(r)=1+o(1), with an exponentially small error in d on each fixed exponent range. This is stronger than the earlier O_beta(log d/d) comparison. The upper error still has a polynomial factor in d; it is not O(dr/N) with an absolute constant.

Let P_* be the last-d-step forced-closure law, including independent fair completion of unused feedback values. For every bounded complex test Phi,

\[
\left|\mathbb E_0[\Phi1_{\{L_f(X)=r\}}]
-\frac1N\mathbb E_*[\Phi1_{\mathrm{success}}]\right|
\le C_\beta d(d\log_2d)^{p_\beta}\frac r{N^2}\|\Phi\|_\infty.
\tag{T2}
\]

Success always requires a first return at exactly r.

## 2. The entropy input, stated explicitly

For a valid rooted cyclic word of length r, let m be its number of repeated length-(d-1) contexts. All length-d windows are distinct, so every context occurs at most twice. Let Q_d^(m)(r) be the mass of this class under the scaled ordinary cycle measure.

There is a cutoff m_0=m_0(d,r) such that

\[
D_r:=\sum_{m\ge m_0}Q_d^{(m)}(r)\le C_\beta2^{-r/d},
\qquad
2^{2dm_0/r}\le\Pi_\beta(d).
\tag{E1}
\]

Here is the entropy/type calculation underlying (E1). For the empirical cyclic block entropies H_h in bits,

\[
H_d=\log_2r,\qquad H_d-H_{d-1}=2m/r,
\]

and stationarity implies

\[
H_h-H_{h-1}\le\frac{\log_2r-2m(d-h)/r}{h}.
\]

A fixed h-type contains at most r 2^{r(H_h-H_{h-1})} rooted words. If M=2^h, the number of possible type vectors is at most

\[
\binom{r+M-1}{M-1}\le[e(1+r/M)]^M.
\]

A deliberately loose common bound for one or two words of total length L is

\[
\log_2 Q^{(m)}\le \frac{Lt}{h}
+2M\log_2[e(1+L/M)]+2\log_2L-\kappa m,
\quad t=\log_2L-h,\quad\kappa=\frac{2d-3h}{h}.
\tag{E2}
\]

Choose q=log_2 d and h=floor(log_2 L-log_2 d-log_2 q). Then

\[
2M\log_2[e(1+L/M)]\le4L/d,
\quad\kappa\ge(2-3\beta)/\beta>0.
\]

Let F=Lt/h+4L/d+2log_2L and m_0=ceil((F+L/d)/kappa). Summation of (E2) gives a tail at most C_beta 2^{-L/d}. Also

\[
\frac{2dm_0}{L}
\le \frac{2}{2-3\beta}(\log_2d+\log_2\log_2d)+O_\beta(1),
\]

which proves (E1) for L=r.

For two words, (E2) does not require context-simplicity of either word. In the length-weighted mixture, all L length-d windows have mass 1/L and every repeated context merges exactly two of them. Thus H_d=log_2L and the final entropy increment is 2m/L even when repetitions occur internally in a cycle. For fixed individual types,

\[
r\delta_h(w_1)+s\delta_h(w_2)\le(r+s)\delta_h^{\mathrm{mix}}
\]

by conditional-entropy concavity, equivalently by nonnegativity of I(last bit; circle label | preceding h-1 bits). The type counting proof therefore applies to all valid disjoint cycle pairs.

## 3. The corrected switching estimate and stopped collisions

Write bar{x} for x with its first bit flipped, and define

\[
S_h(f)=\#\{x:L_f(x)>h,\ T_f^h x=\bar x\}.
\]

If M_h is the total number of repeated contexts in h-cycles, the joining/splitting involution gives

\[
\mathbb ES_h=Q_d(h)-2\mathbb EM_h\le Q_d(h).
\tag{S1}
\]

The survival condition L_f(x)>h is indispensable. The unqualified count of T_f^h x=bar{x} can also include additional laps around a shorter cycle.

For an ordinary trajectory X_i=T_f^iX, define

\[
J_n=1_{\{L_f(X)>n\}}
\sum_{0\le i<j<n}1_{\{u(X_i)=u(X_j)\}}.
\]

On survival, the states are distinct and a context coincidence is a conjugate encounter. Stationarity of the uniform root and (S1) give

\[
\boxed{
\mathbb E_0J_n\le\frac1N\sum_{h=1}^{n-1}(n-h)Q_d(h)
\le\frac{nA_d(n)}N.
}\tag{S2}
\]

This is a single-collision estimate, with the correct stopping condition. It requires no two-cycle theorem.

## 4. Exact open/closing accounting and convexity

Let n=r-d. The ordinary scaled measure and forced successful measure are

\[
\mu_r=N\mathbb P_0(\,\cdot\,,L_f(X)=r),\qquad
\nu_r=\mathbb P_*(\,\cdot\,,\mathrm{success}).
\]

Their masses are Q_d(r) and S_d(r)<=1, respectively. If K counts known closing queries, then

\[
d\nu_r=2^{-K}d\mu_r.\tag{C1}
\]

For a fixed valid unrooted cycle, randomize the root. Let J count repeated queries within its open portion. Since each repeated context has exactly two occurrences,

\[
\boxed{J+K=m.}\tag{C2}
\]

A repeated pair contributes to K only if at least one occurrence is in the closing d positions. Hence

\[
\mathbb E_{\rm roots}K\le2dm/r,
\quad \mathbb E_{\rm roots}J\ge a_rm,
\quad a_r=1-2d/r.
\]

The function phi_m(j)=j2^{j-m} is increasing and convex for j>=0. Using (C2),

\[
\boxed{
\mathbb E_{\rm roots}[J2^{-K}]
\ge a_rm\,2^{-2dm/r}.
}\tag{C3}
\]

For m<m_0 this is at least a_rm/Pi_beta. Integrating over sparse cycles,

\[
\int_{\mathrm{sparse}}m\,d\mu_r
\le\frac{\Pi_\beta}{a_r}\int_{\mathrm{sparse}}J\,d\nu_r
\le\frac{\Pi_\beta}{a_r}\mathbb E_0J_n.
\tag{C4}
\]

The last inequality uses only that the forced law's first n steps have the ordinary law. On success they are a surviving prefix. Thus successful forced histories are a subset of those counted by the nonnegative ordinary stopped statistic J_n. No change-of-law domination for future forced steps is asserted.

Since 1-2^{-K}<=K,

\[
\begin{split}
0\le Q_d(r)-S_d(r)
&\le\frac{2d}{r}\int_{\mathrm{sparse}}m\,d\mu_r+D_r\\
&\le\frac{2d\Pi_\beta}{r-2d}\mathbb E_0J_{r-d}+D_r\\
&\le\frac{2d\Pi_\beta(r-d)}{r-2d}\frac{A_d(r-d)}N+D_r.
\end{split}\tag{C5}
\]

For r>=4d this is at most 4d Pi_beta A_d(r-d)/N+D_r.

## 5. The upper bootstrap

For sufficiently large d, Q_d(h)<=2 for h<d^4. The earlier elementary estimates suffice: Q_d(h)<=1 for h<d; for d<=h<2d the cyclic context-collision estimate gives Q_d(h)<=1+O(d^3 2^{-d/2}); and for 2d<=h<d^4 it gives Q_d(h)<=1+h^3/N.

Let R=floor(N^beta). Since

\[
8d\Pi_\beta R/N+\sup_{r\ge d^4}D_r\longrightarrow0,
\]

induction on r, using (C5) and S_d(r)<=1, proves Q_d(r)<=2 throughout r<=R. Indeed A_d(r-d)<=2(r-d) under the induction hypothesis, whence

\[
Q_d(r)\le1+8d\Pi_\beta r/N+D_r\le2.
\]

Substituting the established bound A_d(n)<=2n back into (C5) yields

\[
0\le Q_d(r)-S_d(r)\le8d\Pi_\beta r/N+D_r.
\tag{U1}
\]

This proves the sharp-constant upper bound using only one-cycle information.

## 6. The lower bound from the middle-first bridge

This uses the two-sided construction, not the one-ended bridge conditioned on an already completed long walk.

Put t=r-2d. Generate an ordinary t-step middle path from a uniform state v to z. Independently choose a uniform w. Add the unique d-step shift paths z->w and w->v. Let G mean that the middle has distinct states and that all 2d added query contexts are mutually distinct and absent from the middle's queried context set.

Define

\[
\delta_r=\frac{(d+2)A_d(r-2d)+2(d+1)A_d(r-d)+2d^2}{N}.
\tag{B1}
\]

The reference probability of G^c is at most delta_r:

* Middle failure costs A_d(t)/N.
* The first added path is coupled until its first reused context to an ordinary forward continuation. Its failure costs (d+1)A_d(t+d)/N.
* Exploring the second path backwards gives the identical bound. Coordinate reversal conjugates the inverse permutation to the same feedback model; the reversed middle starts at a state uniform conditional on f.
* A cross-contact between the two added paths depends only on v,z,w. The ordinary terminal coupling bounds the distance of (v,z) from two independent uniform states by (d+1)A_d(t)/N. Under independent v,z,w, every one of the d^2 possible cross-context matches has probability 2/N, also for overlapping windows.

The last coupling statement follows by making the final d outputs independent fair bits until an already queried context is encountered. The probability of such a terminal encounter is at most (d+1)A_d(t)/N by (S1) and a union bound over separations.

On G every added query is fresh. For fixed middle and w, the ordinary path weight has a factor N^{-2}, the reference weight has N^{-1}, and the forced law has N^{-1} for the first bridge and no extra factor for the last forced bridge. Consequently the scaled ordinary, forced, and reference measures agree exactly on G. In particular

\[
S_d(r)\ge1-\delta_r.\tag{B2}
\]

This calculation uses only marginal failure estimates and an ordinary endpoint coupling, not a joint-collision lemma. Forward and reversed failure events need not be independent.

Now A_d(n)<=2n from Section 5. Therefore, for r>=3d and d>=2,

\[
\delta_r\le\frac{(6d+8)r-6d^2-12d}{N}\le10dr/N.
\]

Since Q_d(r)>=S_d(r), (B2) proves the lower half of (T1). Equation (U1) proves its upper half after absorbing D_r. The positivity of mu_r-nu_r makes its total mass the supremum over bounded complex tests, which proves (T2).

## 7. A comparable-length two-cycle upper bound

Fix beta<2/3 and a finite Theta>=1. Suppose

\[
r,s\ge d^4,\quad L=r+s\le N^\beta,\quad
\max(r,s)/\min(r,s)\le\Theta.
\]

Then

\[
\boxed{
rs\,\mathbb E[C_r(C_s-1_{\{r=s\}})]
\le1+C_{\beta,\Theta}\,
 d(d\log_2d)^{p_\beta(\Theta+1)}\frac LN.
}\tag{P1}
\]

Here the forced exposure order is different: expose BOTH open paths, of lengths r-d and s-d, before forcing either closure. Independent roots are chosen at the beginning. Reject repeated states within or between the paths. Complete the two closures sequentially and require distinct final cycles.

The scaled ordinary measure has total mass Q_d(r,s)=rs E[C_r(C_s-1_{r=s})]. The forced successful measure has mass at most one and density 2^{-K} relative to the scaled ordinary measure. With m the total number of repeated contexts across both final cycles, J the repeats during all open queries, and K the repeats during closing queries, J+K=m again.

Let u=min(r,s). Root averaging gives E K<=2dm/u. The entropy tail (E2) applies to all valid pairs, including internal repetitions. Its cutoff obeys

\[
2^{2dm_0/u}\le\Pi_\beta^{L/u}
\le C_{\beta,\Theta}(d\log_2d)^{p_\beta(\Theta+1)}=:\Pi_{\beta,\Theta}.
\]

For all large d, a=1-2d/u>=1/2. The same convexity argument bounds the sparse weighted m-moment by Pi_{beta,Theta}/a times the ordinary open collision expectation.

For that expectation, internal collisions on each surviving path cost at most n_i(n_i-1)/N, since Q_d(h)<=2. For cross-path queries, conditional on f the two roots are independent uniform states and every fixed iterate is a bijection. Hence each pair of queries has equal contexts with probability exactly 2/N. Dropping the joint survival restriction only increases this nonnegative bound. Thus

\[
\mathbb E J_{\mathrm{open}}
\le\frac{n_1(n_1-1)+n_2(n_2-1)+2n_1n_2}{N}
\le L^2/N.
\]

The gain above forced success is therefore at most

\[
\frac{2d}{u}\frac{\Pi_{\beta,\Theta}}a\frac{L^2}N
+C_\beta2^{-L/d}
\le C_{\beta,\Theta}d\Pi_{\beta,\Theta}L/N.
\]

The forced success mass is at most one, proving (P1).

The comparability assumption is substantive: the factor L/u in the closing exponent is not controlled when the lengths are widely separated. (P1) is an upper bound, not a matching joint asymptotic or a Poisson theorem. No two-cycle lower bound is claimed in this note.

## 8. Consequences and remaining work

For fixed beta<2/3 and b=floor(N^beta), the error in the expected logarithmic product over d^4<=r<=b is bounded by

\[
C_\beta d\Pi_\beta N^{-1}\sum_{r\le b}\log r
=O_\beta(d\Pi_\beta b\log b/N)=o(1).
\]

Thus its expectation agrees with the corresponding harmonic sum to o(1), stronger than an error merely negligible on the CLT scale. This is not a variance estimate.

The unresolved tasks include a uniform two-cycle estimate for widely separated lengths, matching joint asymptotics/connected correlations, exponential-tilt decorrelation, and extension beyond exponent 2/3. The full-order Erdos--Turan theorem remains unproved. The present result should be treated as a working proof, not as a claim of independent external verification.

## 9. Executed finite checks

`thorp_gain_bootstrap_audit.cpp` uses integer arithmetic with arbitrary-precision integer powers. Its recorded run checked:

* 724,864 single cyclic seed words in 15 cases, including 134,060 valid roots;
* the convexity consequence on 6,494 nonzero-repeat unrooted cycles;
* 109 sparse-cutoff weighted inequalities and gain bounds;
* the stopped collision inequality against full feedback enumeration in 11 cases;
* every one of 65,536 width-five feedback environments for the selected pair range, giving 11,588 ordered cycle families and 1,894,702 rooted pairs;
* the open-first identity and convexity inequality for those pairs.

All recorded assertions passed. The earlier two-sided bridge audit was additionally rerun at d=6,r=18, with 72,000 valid rooted cycles and a nonempty good bridge set. It passed its exact measure, forward/reverse, and endpoint comparisons. Neither run tests the asymptotic sparse/dense probabilities.

Build and run:

```sh
g++ -O2 -std=c++17 thorp_gain_bootstrap_audit.cpp -o audit
./audit
```
