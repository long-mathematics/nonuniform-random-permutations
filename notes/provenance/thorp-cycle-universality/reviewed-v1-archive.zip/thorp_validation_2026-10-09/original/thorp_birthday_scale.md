# Closing-query control past $N^{1/3}$: a sparse/dense split reaching the birthday scale

Notation is that of the source note: $N=2^d$, $T_f$ one physical Thorp shuffle, $C_r$ its number of $r$-cycles, $\delta_d(\mathbf r)$ the context-collision probability of the independent cyclic-word reference, $\mathbb P_0$ / $\mathbb P_*$ the ordinary / forced-closure laws, $V_{\rm cl}$ the number of known closing queries. Equation numbers (1)–(26) refer to the source note; new displays are (N1)–(N12). Logarithms $\log_2$ are written out; $d\ge 2$ throughout.

## Part I. Audit of the source argument

I checked every step of §§1–8. I found no error that affects (1), (2) or (26). Points worth recording:

1. **(3), (5), (6).** Correct. Given $A_d$, a repeated context at $i,j$ forces $b_i\ne b_j$ and $b_{i+d}\ne b_{j+d}$, so consistency of $f$ is automatic and the weight is exactly $2^{L-v}$. The rank formula $\min(d-1,\,r-\gcd(r,a))$ is right for *all* $r$ (if fewer than $\gcd$ positions are omitted, exactly $\gcd-(r-d+1)$ residue classes close up), which is what §8 needs for $d\le r<2d$.
2. **(9) is an equality in the cases used.** When $p=q$ the merge costs exactly $2p$. So for one cycle with $m$ repeated contexts, $H_d-H_{d-1}=2m/r$ exactly. This is used below.
3. **(11).** Exact. A successful history $h$ with $v$ distinct queried contexts has $\mathbb P_0(h)=N^{-k}2^{-v}$ and $\mathbb P_*(h)=N^{-k}2^{-(v-(kd-V_{\rm cl}))}$.
4. **Root averaging.** The within-cycle contribution is at most $2d/r$ (the stated bound; the truth is between $d/r$ and $2d/r$). Ties in the length ordering are harmless because $\min(1/r,1/s)$ is symmetric.
5. **(13), (18).** Correct: up to the first repeated context the forced trajectory *is* the reference word, including the wrapped contexts in the closing segment.
6. **§7.** The neighbourhoods $B_\gamma$ are genuine dependency neighbourhoods, so $b_3=0$. The $b_1$ sum includes $\gamma'=\gamma$; that term is covered by the same "two reference words share a context" bound. Process-level Arratia–Goldstein–Gordon then gives a constant multiple of $b_1+b_2$.
7. **§8.** (24) is an exact identity and (25) follows as stated. Typesetting only: the variance display is broken (the lines after "Its mean and variance are"); it should read $\operatorname{Var}(B_b^{(0)})=\tfrac13(\log b)^3-\tfrac13(\log 2d)^3+O(1)$.
8. **Where the loss is.** Exact enumeration ($d=5,\dots,8$, $2d\le r\le 20$) gives $\mathbb E C_r^{\rm rep}$ between $0.09\,r/N$ and $0.39\,r/N$, against the bound $r(r-1)/N$ of (14). The factor $r$ in (4) is an artefact of Jensen applied to the worst case $\mathbb E_{\rm roots}V_{\rm cl}\le\log_2 r$, as §9 of the note suspects.

## Part II. The extension

### Statement

> **Theorem (birthday-scale Poisson approximation).** There is an absolute constant $C$ such that for $2d\le b\le\sqrt N$,
> $$d_{\rm TV}\Bigl(\mathcal L\bigl((C_r)_{2d\le r\le b}\bigr),\ \bigotimes_{r=2d}^{b}\operatorname{Poisson}(1/r)\Bigr)\ \le\ C\,d^{48}\,\frac{b^2}{N}.\tag{N1}$$
> Consequently (2) and the functional limit (26) hold for every fixed $0<\alpha<\tfrac12$.

The exponent $48$ is crude (see the remark after (N9)); the point is that it is a power of $\log N$.

### Idea

In (12) the penalty $2^{V_{\rm cl}}$ is bounded through $\mathbb E_{\rm roots}V_{\rm cl}\le 2dm/r$, where $m$ is the number of repeated contexts. That is harmless unless $m\gtrsim r/d$. So split the cycle families by $m$:

* **sparse**, $m<m_0$ with $m_0\asymp r\log d/d$: the closing penalty is $d^{O(1)}$, not $r$;
* **dense**, $m\ge m_0$: no forcing at all. The entropy increments that proved (10) also show that a dense word has a deficient block entropy at a *shorter* scale $d'\approx\log_2 r-2\log_2 d$, where empirical types can be counted. Dense words are then so few that even the full weight $2^m$ leaves a super-polynomially small total.

### 1. Counting cyclic words by their $d'$-block type

For a cyclic binary word $w$ of length $n$ and $k\le n$, let $H_k(w)$ be the entropy (bits) of its empirical cyclic $k$-block distribution and $\delta_k=H_k-H_{k-1}$. The cyclic *$k$-type* of $w$ is its vector of $k$-block counts.

**Lemma 1.** The number of rooted cyclic words of length $n$ with a given $k$-type is at most $n\,2^{n\delta_k}$. The number of $k$-types is at most $(n+1)^{2^k}$.

*Proof.* Let $n(u)$ be the count of the $k$-block $u$ and $q(u)=n(u)/n(\mathrm{prefix}_{k-1}(u))$. For any $w$ of this type, $\prod_{i=1}^{n}q(w_i\cdots w_{i+k-1})=\prod_u q(u)^{n(u)}=2^{-n\delta_k}$. Let $\mu$ be the law on $\{0,1\}^n$ that draws the first $k-1$ bits from the empirical $(k-1)$-block distribution and each later bit from $q$. Then $\mu(w)\ge \tfrac1n\prod_{i=1}^{n}q(\cdot)=2^{-n\delta_k}/n$, since the initial block has empirical mass at least $1/n$ and the omitted factors are at most $1$. Sum over $w$. The second claim is trivial. $\square$

**Lemma 2 (entropy deficit).** Let $w$ be a cyclic word of length $r\ge d$ with all $d$-windows distinct and exactly $m$ repeated contexts. Then for $1\le d'\le d$,
$$\delta_{d'}\ \le\ \frac{H_{d'}}{d'}\ \le\ \frac1{d'}\Bigl(\log_2 r-\frac{2m(d-d')}{r}\Bigr).\tag{N2}$$

*Proof.* $H_d=\log_2 r$, and $\delta_d=2m/r$ by audit point 2. Increments are nonincreasing, so $H_d-H_{d'}\ge(d-d')\delta_d$ and $H_{d'}\ge d'\delta_{d'}$. $\square$

**Two cycles.** For rooted words $w_1,w_2$ of lengths $r\le s$, $L=r+s$, both context-simple, with all $L$ windows distinct and exactly $m$ shared contexts, use the *length-weighted* mixture (pick one of the $L$ positions uniformly). It is stationary, every window has mass $1/L$, and each shared context merges two atoms of mass $1/L$, so $H_d=\log_2L$ and $\delta_d=2m/L$; (N2) holds with $r$ replaced by $L$. Conditional entropy is concave in the joint law, so $r\,\delta_{d'}(w_1)+s\,\delta_{d'}(w_2)\le L\,\delta_{d'}^{\rm mix}$, and by Lemma 1 the number of pairs with given pair of $d'$-types is at most $rs\,2^{L\delta^{\rm mix}_{d'}}$.

### 2. The dense tail

Fix $L$ with $d^4\le L\le 2\sqrt N$ ($L=r$ for one cycle, $L=r+s$ for a pair) and put
$$d'=\lfloor\log_2L-2\log_2d\rfloor,\qquad t=\log_2L-d'\in[2\log_2d,\,2\log_2d+1),\qquad m_0=\Bigl\lceil\frac{6Lt}{2d-3d'}\Bigr\rceil.\tag{N3}$$
Then $2\le d'\le d/2$, so $\kappa:=(2d-3d')/d'\ge1$.

Let $Q^{(m)}$ be the part of $Q_d$ coming from families with exactly $m$ repeated contexts (one cycle) or exactly $m$ shared contexts between two context-simple cycles. In both cases $Q^{(m)}=2^{m-L}\cdot\#\{\text{such rooted families}\}$. By Lemmas 1–2,
$$\log_2Q^{(m)}\ \le\ m-L+2\cdot2^{d'}\log_2(L+1)+2\log_2L+\frac{L\log_2L-2m(d-d')}{d'}
=\frac{Lt}{d'}+2^{d'+1}\log_2(L+1)+2\log_2L-\kappa m.\tag{N4}$$
Here $2^{d'+1}\log_2(L+1)\le 2L(d+1)/d^2\le 3L/d$ and $2\log_2L\le d+2\le L/d$, while $Lt/d'\ge 4L\log_2d/d\ge4L/d$. Hence $\log_2Q^{(m)}\le 3Lt/d'-\kappa m$, and since $\kappa m_0\ge 6Lt/d'$,
$$\boxed{\ \sum_{m\ge m_0}Q^{(m)}\ \le\ 2^{\,1-3Lt/d'}\ \le\ 2^{\,1-12d^3}.\ }\tag{N5}$$

### 3. The sparse part

For a single cycle with $m$ repeated contexts, $\mathbb E_{\rm roots}V_{\rm cl}\le 2dm/r$ (each repeated context contributes at most $2d/r$; no entropy bound is needed). For two context-simple cycles sharing $m$ contexts, $\mathbb E_{\rm roots}V_{\rm cl}=dm/s\le 2dm/L$. By Jensen and (11), for the root-invariant event $E_m$ of successful histories with parameter $m$,
$$Q^{(m)}\ \le\ 2^{2dm/L}\,\mathbb P_*(E_m).\tag{N6}$$
For $m<m_0$ the factor is at most
$$\Pi:=2^{2dm_0/L}\le 2^{\,24t+2d/L}\le 2^{25}d^{48}.\tag{N7}$$
The events $E_m$ are disjoint, and (13), (18) bound their union: $\sum_{m\ge1}\mathbb P_*(E_m)\le\delta_d(r)\le r(r-1)/N$ for one cycle, and $\le 2rs/N$ for a context-simple intersecting pair.

### 4. The two improved estimates

Adding (N5) to (N6)–(N7): for $d^4\le r\le2\sqrt N$,
$$\boxed{\ Q_d^{\rm rep}(r)\le\Pi\,\frac{r(r-1)}N+2^{1-12d^3},\qquad \mathbb E C_r^{\rm rep}\le\Pi\,\frac{r-1}{N}+\frac{2^{1-12d^3}}r,\ }\tag{N8}$$
and for $r,s\ge2d$ with $d^4\le r+s\le2\sqrt N$,
$$\boxed{\ \mathbb E X_{r,s}\le\frac{2\Pi}{N}+\frac{2^{1-12d^3}}{rs}.\ }\tag{N9}$$
These replace (14) and (16): the closing penalties $r$ and $2\sqrt{rs}$ become $\Pi=d^{O(1)}$.

*Remark on constants.* Taking $m_0=(1+\varepsilon)Lt/(2d-3d')$ and tracking $\log_2L/d=\beta$ gives $\Pi=d^{4(1+\varepsilon)/(2-3\beta)+o(1)}$, i.e. about $d^{8}$ at $\beta=\tfrac12$. I have not optimised further.

### 5. Proof of (N1)

Take $2d\le b\le\sqrt N$; all lengths below are at most $b$, so $L\le2\sqrt N$.

*Non-context-simple cycles.* Use (14) for $r<d^4$ and (N8) otherwise:
$$\mathbb P\{\text{some non-context-simple cycle has length in }[2d,b]\}\le\frac{d^{12}}{3N}+\Pi\frac{b^2}{2N}+b\,2^{1-12d^3}.\tag{N10}$$

*Poisson approximation of the context-simple counts.* §7 of the note applies verbatim: same indicators, same neighbourhoods, $b_3=0$, $b_1\le2b^2/N$. For $b_2$ use (16) when $r+s<d^4$ and (N9) otherwise:
$$b_2\le\sum_{r+s<d^4}\frac{4\sqrt{rs}}N+\sum_{r,s\le b}\Bigl(\frac{2\Pi}N+\frac{2^{1-12d^3}}{rs}\Bigr)\le\frac{2d^{12}}N+2\Pi\frac{b^2}N+2^{1-12d^3}(1+\ln b)^2.\tag{N11}$$

*Means.* (22) is unchanged: $\sum_r|\lambda_r-1/r|=O(b^2/N)$.

Since $b\ge2d$, $d^{12}\le\Pi b^2$, and the $2^{-12d^3}$ terms are far below $1/N$. Collecting terms gives (N1). $\square$

### 6. Consequences

Fix $\alpha<\tfrac12$ and $b=\lfloor N^\alpha\rfloor$. Then $d^{48}b^2/N\to0$, so the coupling with independent $\operatorname{Poisson}(1/r)$ variables holds with probability tending to one, and §8 of the note (which uses nothing about $b$ beyond that coupling and $\log b\asymp d$) gives (2) and (26) on $[0,\alpha]$ for every $\alpha<\tfrac12$. More precisely the coupling survives for $b=o(\sqrt N/d^{24})$.

*A priori bound past the birthday scale.* The dense estimate needs only $\log_2L\le\alpha d$ with $\alpha<\tfrac23$ (then $\kappa\ge(2-3\alpha)/\alpha>0$ in (N4)). The same proof gives, for $d^4\le r\le N^{\alpha}$,
$$Q_d(r)\le 1+C_\alpha d^{c_\alpha},\qquad\text{so}\qquad \mathbb EC_r\le\frac{C_\alpha d^{c_\alpha}}{r},\qquad c_\alpha=\frac{24}{2-3\alpha}.\tag{N12}$$
This is an upper bound only; it is not a Poisson statement.

## Part III. Status and what remains

**What was checked by machine** (`audit.py`, exact rational arithmetic over all words):

* identity (3) against brute force over every feedback function, $d=3,4$, all $r\le16$;
* (4), (13) and the graded inequality (N6) for single cycles, $d=5,\dots,8$, even $r$ from $2d$ to $20$;
* Lemma 1 and (N2) for every valid word and every $1\le d'\le d$, for $d=4,5,6$, $r\le16$;
* (N6) and (18) for context-simple pairs at seven small $(r,s,d)$.

All passed. These sizes are far from the asymptotic regime $r\ge d^4$, so they test the ingredients, not (N1) itself. The two-cycle mixture inequality (concavity step) was not machine-checked. The proof has not been read by anyone else.

**Not used.** Before finding the entropy route I tested a rank lemma for systems of context coincidences on one circle (2–5 pairs, about $2.5$ million configurations, no failures). The argument above does not rely on it.

**The remaining gap.** $\sqrt N$ is a real boundary for this method, not a technical one. For $r\gg\sqrt N$, $\delta_d(r)\to1$: a typical $r$-cycle has repeated contexts, context-simple cycles no longer carry the mass, and $Q_d=(1-\delta_d)+Q_d^{\rm rep}$ is $1+o(1)$ only through $Q^{\rm rep}_d\to1$. Upper bounds on $Q^{\rm rep}$ with any multiplicative loss (even the $\Pi$ of (N7)) cannot show that. The next step therefore needs an *asymptotic* evaluation of the sparse part, $\sum_{m<m_0}Q^{(m)}$, with the closing penalty $\mathbb E_{\rm roots}2^{-V_{\rm cl}}$ computed to $1+o(1)$ rather than bounded by Jensen, together with a dependency structure for the Poisson step that tolerates shared contexts. (N12) supplies the a priori control such an argument would start from, up to $N^{2/3-\varepsilon}$.
