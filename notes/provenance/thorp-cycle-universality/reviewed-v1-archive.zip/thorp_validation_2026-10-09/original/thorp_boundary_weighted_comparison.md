# A relative boundary comparison for one Thorp permutation

## Scope

Let N=2^d, choose the feedback values independently and fairly, and put

\[
T_f(x_1,\ldots,x_d)=(x_2,\ldots,x_d,x_1\oplus f(x_2,\ldots,x_d)).
\]

The initial state X is uniform and independent of f. Write tau=L_f(X) for its cycle length, C_r for the number of r-cycles, and Q_d(r)=r E C_r=N P(tau=r).

This note proves a relative comparison with the last-d-step forced-closure law. It uses the entropy/type estimates developed in `thorp_birthday_scale.md`, with their proofs restated in the form needed here. It does not use the protected-cut construction, a full-permutation mixing theorem, or an independent-round model.

For every fixed 0<beta<2/3, uniformly for d^4 <= r <= N^beta,

\[
Q_d(r)=1+O_\beta((\log d)/d).
\]

More generally, for every bounded complex function Phi of the completed feedback environment and root,

\[
\left|E_0[\Phi 1_{\{\tau=r\}}]-\frac1N E_*[\Phi 1_{\mathrm{success}}]\right|
\le \frac{C_\beta\log d}{Nd}\|\Phi\|_\infty.
\]

The sharper error O(dr/N) is not established. Neither joint cycle asymptotics nor the full Erdos--Turan theorem follows from this one-cycle result alone.

## 1. The actual and forced measures

The ordinary law P_0 samples f and X uniformly. The forced law P_* follows the actual trajectory for r-d steps, revealing f only as necessary, then prescribes the final d output bits to be the initial state. A fresh closing query is set to satisfy that prescription. A previously queried value is never changed; a contradiction is failure. Success requires a first return at exactly r. Unqueried feedback values are completed by independent fair bits.

Let K count previously known queries among the final d closing steps. On successful rooted histories, define finite measures

\[
\mu_r=N P_0(\,\cdot\,,\tau=r),\qquad
\nu_r=P_*(\,\cdot\,,\mathrm{success}).
\]

Exactly d-K closing queries are fresh. Their ordinary probability factor is 2^{-(d-K)}. Consequently,

\[
 d\nu_r=2^{-K}d\mu_r. \tag{1}
\]

Thus mu_r has mass Q_d(r), nu_r has mass S_d(r)<=1, and mu_r-nu_r is nonnegative. In particular,

\[
\sup_{\|\Phi\|_\infty\le1}
\left|N E_0[\Phi1_{\{\tau=r\}}]-E_*[\Phi1_{\mathrm{success}}]\right|
=Q_d(r)-S_d(r). \tag{2}
\]

The task is to show that this mass difference tends to zero, not merely that the ordinary probability of a boundary contact is small.

## 2. Terminal reuse and endpoint smoothing

Write bar{x} for the state obtained by changing the first bit, and define

\[
S_h(f)=\#\{x:L_f(x)>h,\ T_f^h x=\bar x\}.
\]

If M_h(f) is the total number of repeated contexts in h-cycles, feedback-bit switching gives

\[
E S_h=Q_d(h)-2 E M_h\le Q_d(h). \tag{3}
\]

The restriction L_f(x)>h is essential. The bijection joins an h-cycle at a state y whose conjugate x is outside the cycle; in the joined permutation, T^h x=y=bar{x}. The inverse flip splits off that h-cycle.

Put

\[
A_d(n)=\sum_{h\le n}Q_d(h).
\]

For an ordinary trajectory of n steps, n>=d, let R_{n,d} mean that one of its final d queries repeats an earlier context. Then

\[
P(R_{n,d})\le \frac{d+1}{N}A_d(n). \tag{4}
\]

Indeed, P(tau<=n)=A_d(n)/N. On tau>n, states are distinct, so equal contexts mean conjugate states. For query times j<i and h=i-j, stationarity of the uniform root and (3) bound the probability of such a conjugate encounter, with tau>n, by Q_d(h)/N. Each h appears in at most d pairs with i in the final d query positions. Summing proves (4).

Couple the last d outputs to independent fair bits, using the same bit whenever the actual query is fresh. The comparison endpoint is uniform and independent of the initial root. Therefore

\[
 d_{\rm TV}(\mathcal L(X_0,X_n),U_N\otimes U_N)
 \le\frac{d+1}{N}A_d(n). \tag{5}
\]

The same bounds hold in reverse time: reversing coordinates conjugates T_f^{-1} to T_{\widetilde f}, where widetilde f(u)=f(reverse(u)); this is the same feedback-function distribution and has the same cycle counts.

## 3. The two-sided bridge

Assume r>=3d, and let t=r-2d. Under a reference law R:

1. Generate an ordinary middle trajectory of t steps from v, uniform on the states, to z.
2. Independently choose w uniformly on the states.
3. Use the unique d-step shift path from z to w and the unique d-step shift path from w to v.

The two added paths are encoded by the linear word z w v of length 3d. Their feedback values are not required to agree with the already revealed values unless we restrict to the good event below.

Let G be the event that the middle path has t+1 distinct states and that all 2d added query contexts are distinct and absent from the middle's queried context set. Then G produces a valid first closure of length r. A repeated state before the final return would either repeat a middle state within the middle, or cause a repeated queried context among the middle and added paths.

Define

\[
\delta_r=
\frac{(d+2)A_d(r-2d)+2(d+1)A_d(r-d)+2d^2}{N}. \tag{6}
\]

Then

\[
R(G^c)\le\delta_r. \tag{7}
\]

### Proof of the reference bound

Middle failure costs A_d(t)/N.

The forward added path z to w has independent fair proposed output bits. Until its first reused context it couples to the actual continuation of the middle. Thus its probability of meeting a middle context or repeating one of its own contexts equals the corresponding ordinary terminal-reuse probability and is at most (d+1)A_d(t+d)/N.

Explore the added path w to v backwards. Its proposed input bits are also independent fair bits. The reversed middle starts at z, which is uniform conditional on f, and ends at v. Reverse-time version (4) gives the same bound (d+1)A_d(t+d)/N. This covers contacts with the middle and internal contacts in this second path. No independence between these two contact events is needed.

It remains to control a context shared by the two added paths. This event depends only on (v,z,w). By (5), (v,z) is within (d+1)A_d(t)/N of two independent uniform states. Adding the independent w preserves that distance. Under independent v,z,w, z w v is an iid binary word. Every pair of distinct length-(d-1) windows agrees with probability 2^{-(d-1)}=2/N, including overlapping windows: the bit-equality graph is a forest. There are d^2 cross pairs. Hence the cross-contact probability is at most

\[
\frac{(d+1)A_d(t)}N+\frac{2d^2}N.
\]

The sum of these bounds is (6).

### Exact agreement on good histories

On G, all 2d added queries are fresh. For a fixed middle and a fixed w, the ordinary probability of the prescribed 2d outputs is N^{-2}; the reference probability of w is N^{-1}. Multiplication of the ordinary measure by N gives the same weight. Under P_*, the first d added outputs occur with probability N^{-1}, and the last d are forced. Uniform completion of unused feedback values agrees in all constructions.

Consequently,

\[
\mu_r|_G=\nu_r|_G=R|_G. \tag{8}
\]

In particular,

\[
\nu_r(G)\ge1-\delta_r,\quad
S_d(r)\ge1-\delta_r,\quad
\nu_r(G^c)\le\delta_r. \tag{9}
\]

This proves that the forced bridge succeeds with probability tending to one whenever the available a priori bounds make delta_r small. It remains to control the weight of its bad successful histories under mu_r.

## 4. Entropy bounds needed for that weight

For a valid rooted cycle of length r let m be its number of repeated contexts. Its cyclic empirical block entropies, in bits, obey

\[
H_d=\log_2r,\qquad H_d-H_{d-1}=2m/r.
\]

By monotonicity of stationary conditional entropies, for 1<=h<=d,

\[
\delta_h:=H_h-H_{h-1}\le H_h/h
\le \frac{\log_2r-2m(d-h)/r}{h}. \tag{10}
\]

For a fixed empirical h-type, the number of rooted words is at most r 2^{r delta_h}; the total number of types is at most (r+1)^{2^h}. The fixed-type bound follows by assigning the empirical Markov law to the words: each such word has probability at least 2^{-r delta_h}/r.

Let Q_d^{(m)}(r) be the mass of the cycles with m repeated contexts under mu_r. Equivalently, this is 2^{m-r} times the number of valid rooted cyclic words with that m. A convenient, deliberately loose consequence of the type count is

\[
\log_2 Q_d^{(m)}(r)
\le \frac{ru}{h}+2^{h+1}\log_2(r+1)+2\log_2r
-\kappa m, \tag{11}
\]

where u=log_2r-h and kappa=(2d-3h)/h.

Fix beta<2/3 and d^4<=r<=N^beta. Choose

\[
h=\lfloor\log_2r-2\log_2d\rfloor,
\quad u\in[2\log_2d,2\log_2d+1),
\quad m_0=\left\lceil\frac{6ru}{2d-3h}\right\rceil.
\]

Then kappa is bounded below by (2-3beta)/beta>0. For sufficiently large d, the positive part of (11) is at most 3ru/h. Summing the geometric tail yields

\[
D_r:=\sum_{m\ge m_0}Q_d^{(m)}(r)
\le C_\beta 2^{-3ru/h}
\le C_\beta 2^{-r/d}. \tag{12}
\]

Now fix a completed environment and an unrooted r-cycle. With its root uniform, each repeated context contributes to K with probability at most 2d/r. For the sparse cycles m<m_0,

\[
E_{\rm roots}K\le\frac{2dm_0}{r}=:\Gamma_\beta(d,r)
\le\frac{24}{2-3\beta}\log_2d+C_\beta. \tag{13}
\]

These are the two properties needed below: exponentially small dense mass and O_beta(log d) average closing exponent on each sparse cycle. We do not assert a pointwise bound on K.

For completeness, the same properties give Q_d(r)<=2^{Gamma_beta}+D_r, since Jensen and (1) imply mu_r(sparse)<=2^{Gamma_beta}nu_r(sparse). Thus Q_d(r)<=C_beta d^{c_beta}, with c_beta=24/(2-3beta). The shorter range can be included in that polynomial: Q_d(h)<=1 for h<d by primitive necklaces; for d<=h<d^4, root entropy gives E_roots K<=log_2h, hence Q_d(h)<=h by (1) and Jensen. Therefore

\[
A_d(n)\le C_\beta d^{c_\beta}n,\qquad n\le N^\beta. \tag{14}
\]

## 5. A root-averaged boundary comparison inequality

Let B=G^c on successful histories. For a fixed sparse unrooted cycle gamma, including its completed environment, let

\[
q_\gamma=P_{\rm roots}(B),\qquad
 a_\gamma=E_{\rm roots}[2^{-K}1_B].
\]

All roots of gamma have equal weight under mu_r. Also K=0 on G.

For any 0<eta<1, split sparse cycles according to q_gamma<=eta or q_gamma>eta.

For the first class,

\[
\mu_r(B,q_\gamma\le\eta,\mathrm{sparse})
\le\frac{\eta}{1-\eta}\mu_r(G,q_\gamma\le\eta,\mathrm{sparse})
\le\frac{\eta}{1-\eta}. \tag{15}
\]

For the second class, conditional Jensen and (13) give

\[
a_\gamma
\ge q_\gamma 2^{-E[K1_B]/q_\gamma}
\ge q_\gamma 2^{-\Gamma_\beta/\eta}.
\]

Integrating and using (9),

\[
\mu_r(B,q_\gamma>\eta,\mathrm{sparse})
\le2^{\Gamma_\beta/\eta}\nu_r(B)
\le2^{\Gamma_\beta/\eta}\delta_r. \tag{16}
\]

The dense class costs at most D_r. Since (1) and K=0 on G imply 0<=Q_d(r)-S_d(r)<=mu_r(B), we have the finite comparison

\[
\boxed{
0\le Q_d(r)-S_d(r)
\le \frac{\eta}{1-\eta}
+2^{\Gamma_\beta/\eta}\delta_r+D_r.
}\tag{17}
\]

This inequality retains the boundary weight. It does not multiply an ordinary exceptional probability by N or bound 2^K by its maximum.

When 0<delta_r<1 and log_2(1/delta_r)>=4Gamma_beta, choose eta=2Gamma_beta/log_2(1/delta_r). Then

\[
\boxed{
0\le Q_d(r)-S_d(r)
\le \frac{4\Gamma_\beta}{\log_2(1/\delta_r)}
+\sqrt{\delta_r}+D_r.
}\tag{18}
\]

## 6. The relative asymptotic

By (6) and (14),

\[
\delta_r\le C_\beta d^{c_\beta+1}\frac rN,
\qquad d^4\le r\le N^\beta.
\]

Thus log_2(1/delta_r)>=(1-beta)d-O_beta(log d), whereas Gamma_beta=O_beta(log d) and D_r<=C_beta2^{-d^3}. Formula (18) gives uniformly

\[
Q_d(r)-S_d(r)=O_\beta((\log d)/d).
\]

Together with 1-delta_r<=S_d(r)<=1,

\[
\boxed{r E C_r=1+O_\beta((\log d)/d).}\tag{19}
\]

Equations (2) and (18) prove the bounded-test relative comparison stated at the beginning. In particular,

\[
\boxed{P_0(\tau=r)=\frac1N\left(1+O_\beta((\log d)/d)\right).}\tag{20}
\]

The conditional law given tau=r and the forced law given success are also within O_beta((log d)/d) in total variation: since mu_r>=nu_r, their distance is at most (Q_d(r)-S_d(r))/Q_d(r).

This is a statement for a uniform independent root, not a claim uniform over deterministic seeds. The bounded-test comparison includes imaginary exponential tests, but does not show that such tests factor from the forced closure. Joint cycle estimates and tilted decorrelation remain additional requirements for an Erdos--Turan proof.

## 7. A first-moment consequence

For b=floor(N^beta), beta<2/3, summing (19) gives

\[
E\sum_{d^4\le r\le b} C_r\log r
=\frac12(\log b)^2-\frac12(\log d^4)^2
+O_\beta(d\log d).
\]

Thus the middle-range additive centering error is negligible relative to d^{3/2}. This is not a variance estimate or a central limit theorem.

## 8. Finite verification

`thorp_boundary_bridge_audit.cpp` uses integer arithmetic and multiprecision integer powers. The recorded run covers 15 cases with d=4,5,6,7 and r>=3d. It enumerates 6,123,520 cyclic seed words, including 1,389,206 valid rooted cycles, and checks:

- the normalization of the actual-prefix reference likelihood;
- equality of the reference, ordinary scaled, and forced measures on good histories;
- both forward and reversed first-contact comparisons;
- the endpoint-TV bound for cross-boundary contacts;
- 68,358 root-averaged entropy inequalities;
- 49,710 conditional Jensen inequalities, with denominators and powers cleared.

All checks passed. The supporting corrected switching identity was also rerun on 4,224 marked atoms in dimensions 3 and 4, along with 34 terminal-reuse inequalities. Small dimensions do not test the large-d sparse/dense asymptotics. Some small cases have no good bridges; the d=5,6,7 tests include nonempty good sets. These computations supplement the proofs above and are not an independent verification of the asymptotic theorem.

Build and run:

```sh
g++ -O2 -std=c++17 thorp_boundary_bridge_audit.cpp -o audit
./audit
# Optional single case:
./audit 7 21
```

The exact output is in `thorp_boundary_bridge_audit_results.jsonl`; aggregate counts are in `thorp_boundary_bridge_audit_summary.json`.
