#!/usr/bin/env python3
"""Exact finite checks for longest-last Thorp cycle induction.
All asserted inequalities use Python integers. Sampling, where used, is
only for deterministic identities; aggregate moment inequalities use
complete enumeration of feedback functions in dimensions 3 and 4.
"""
from __future__ import annotations
from collections import Counter
from itertools import permutations, product
import json, random
from pathlib import Path

COUNTS=Counter()

def permutation(d:int, f:int)->list[int]:
    mask=(1<<(d-1))-1
    return [((x&mask)<<1)|((x>>(d-1))^((f>>(x&mask))&1)) for x in range(1<<d)]

def cycles(p:list[int])->list[list[int]]:
    seen=set(); out=[]
    for x in range(len(p)):
        if x in seen: continue
        c=[]; y=x
        while y not in seen:
            seen.add(y); c.append(y); y=p[y]
        assert y==x
        out.append(c)
    return out

def cpow(c:Counter)->int:
    out=1
    for v in c.values():
        if v: out*=v**v
    return out

def block_counts(c:list[int],d:int,h:int)->Counter:
    bits=[x>>(d-1) for x in c]
    if h==0:return Counter({0:len(c)})
    n=len(c); result=Counter()
    for i in range(n):
        u=0
        for j in range(h):u=(u<<1)|bits[(i+j)%n]
        result[u]+=1
    return result

def check_family(d:int, family:list[list[int]], entropy:bool=True):
    k=len(family); r=len(family[-1]); L=sum(map(len,family)); mask=(1<<(d-1))-1
    assert all(len(c)<=r for c in family)
    prior={x&mask for c in family[:-1] for x in c}
    ctx=[x&mask for x in family[-1]]
    allctx=Counter(x&mask for c in family for x in c)
    assert max(allctx.values())<=2
    mtotal=L-len(allctx)
    mnew=r-len(set(ctx)-prior)
    Jsum=Ksum=S=T=0
    for a in range(r):
        known=set(prior); J=K=0
        for i in range(r):
            u=ctx[(a+i)%r]
            old=(u in known)
            if i<r-d:J+=old
            else:K+=old
            known.add(u)
        assert J+K==mnew
        # The last d queries contain at most d known queries.
        assert 0<=K<=d
        # Equality of exponents in the partial-forcing likelihood identity.
        vprior=len(prior); vtotal=len(allctx)
        assert vprior+r-J == vtotal+K
        Jsum+=J; Ksum+=K; S+=J*(1<<(d-K)); T+=(1<<(d-K))
        COUNTS[f'root_identities_k{k}']+=1
    assert Ksum<=2*d*mnew
    assert Jsum>=max(0,(r-2*d)*mnew)
    if r>=2*d and mnew:
        # (E[J 2^-K] >= (1-2d/r)mnew 2^(-2d*mnew/r))^r.
        lhs=(S**r)*(1<<(2*d*mnew))
        rhs=(((r-2*d)*mnew)*(1<<d))**r
        assert lhs>=rhs
        COUNTS[f'convexity_checks_k{k}']+=1
    COUNTS[f'families_k{k}']+=1
    if not entropy:return T,S,mnew
    for h in range(1,d+1):
        separate=[block_counts(c,d,h) for c in family]
        sep_pre=[block_counts(c,d,h-1) for c in family]
        combined=Counter(); pre=Counter()
        for cc in separate:combined.update(cc)
        for cc in sep_pre:pre.update(cc)
        assert cpow(combined)>=(1<<(2*mtotal*(d-h)))
        left=cpow(combined); right=cpow(pre)
        for cc in sep_pre:left*=cpow(cc)
        for cc in separate:right*=cpow(cc)
        assert left<=right
        COUNTS[f'entropy_and_mixture_checks_k{k}']+=1
        if any(len(c)<h for c in family):COUNTS['entropy_with_short_components']+=1
    return T,S,mnew

def exhaustive(d:int,maxk:int=4)->None:
    N=1<<d; half=N//2; nf=1<<half
    Q=[Counter() for _ in range(maxk+1)]
    E=[Counter() for _ in range(maxk+1)]
    NU=[Counter() for _ in range(maxk+1)]
    NJ=[Counter() for _ in range(maxk+1)]
    MM=[Counter() for _ in range(maxk+1)]
    for f in range(nf):
        p=permutation(d,f); cs=cycles(p); nc=len(cs)
        for k in range(1,min(maxk,nc)+1):
            for inds in permutations(range(nc),k):
                fam=[cs[i] for i in inds]; lens=tuple(map(len,fam))
                weight=1
                for x in lens:weight*=x
                Q[k][lens]+=weight
                if lens[-1]>=2*d and max(lens)==lens[-1]:
                    T,S,mnew=check_family(d,fam)
                    wp=weight//lens[-1]
                    NU[k][lens]+=wp*T; NJ[k][lens]+=wp*S; MM[k][lens]+=weight*mnew
        # Marked conjugate endpoints; prior cycles are unchanged by the flip.
        for k in range(1,maxk+1):
            if k-1>nc:continue
            for prev in permutations(range(nc),k-1):
                prevset=set(prev); lens=tuple(len(cs[i]) for i in prev)
                rootweight=1
                for r in lens:rootweight*=r
                for ci,c in enumerate(cs):
                    if ci in prevset:continue
                    pos={x:j for j,x in enumerate(c)}
                    for j,y in enumerate(c):
                        by=y^half
                        if by not in pos:continue
                        h=(pos[by]-j)%len(c)
                        assert 0<h<len(c)
                        E[k][lens+(h,)]+=rootweight
    for k in range(1,maxk+1):
        for key,value in E[k].items():
            assert value<=Q[k][key],(d,k,key,value,Q[k][key])
            COUNTS[f'marked_aggregate_bounds_k{k}']+=1
    for k in range(1,maxk+1):
        for lens, nu in NU[k].items():
            prev=lens[:-1]; r=lens[-1]; n=r-d; P=sum(prev)
            qp=nf if k==1 else Q[k-1][prev]
            assert nu<=(1<<d)*qp
            gain=(1<<d)*Q[k][lens]-nu
            assert gain>=0
            assert gain*r<=2*d*(1<<d)*MM[k][lens]
            rhs=sum((n-h)*Q[k][prev+(h,)] for h in range(1,n))+2*n*P*qp
            assert NJ[k][lens]<=rhs,(d,k,lens,NJ[k][lens],rhs)
            COUNTS[f'partial_forcing_and_open_collision_bounds_k{k}']+=1
    COUNTS['feedback_environments_exhaustive']+=nf


def check_short_types()->None:
    # For h > n, a fixed cyclic h-type determines one necklace.
    for n in range(1,8):
        for h in range(n+1,11):
            types=Counter()
            for b in product((0,1),repeat=n):
                counts=Counter()
                for i in range(n):
                    u=0
                    for j in range(h):u=(u<<1)|b[(i+j)%n]
                    counts[u]+=1
                types[tuple(sorted(counts.items()))]+=1
            for multiplicity in types.values():
                assert multiplicity<=n
                COUNTS['short_word_type_classes']+=1


def sampled_families()->None:
    rng=random.Random(20261009)
    # Deterministic inequalities only: no probabilistic conclusion from this sample.
    for d,nsamp in ((5,256),(6,256)):
        for _ in range(nsamp):
            f=rng.getrandbits(1<<(d-1)); cs=cycles(permutation(d,f)); nc=len(cs)
            for k in range(2,min(4,nc)+1):
                eligible=[]
                for inds in permutations(range(nc),k):
                    fam=[cs[i] for i in inds]
                    if len(fam[-1])>=2*d and all(len(c)<=len(fam[-1]) for c in fam):
                        eligible.append(fam)
                for fam in eligible[:12]:check_family(d,fam)
            COUNTS['feedback_environments_sampled']+=1

if __name__=='__main__':
    check_short_types()
    exhaustive(3); exhaustive(4)
    sampled_families()
    output={'status':'all assertions passed','checks':dict(sorted(COUNTS.items())),
      'limitations':['No finite computation tests the large-d entropy tail.',
      'Marked expectation bounds use exhaustive d=3,4 only.',
      'Dimensions 5 and 6 are seeded samples testing deterministic inequalities.']}
    path=Path('/mnt/data/thorp_multiscale_cycle_audit_results.json')
    path.write_text(json.dumps(output,indent=2)+'\n')
    print(json.dumps(output,indent=2))
