#!/usr/bin/env python3
"""Finite deterministic checks of the multi-middle bridge construction.
Seeded samples are not estimates of an asymptotic probability.
"""
from __future__ import annotations
from collections import Counter
import json, random
from pathlib import Path

RNG=random.Random(2026100902)
C=Counter()

def tf(d,f,x):
    return ((x&((1<<(d-1))-1))<<1)|((x>>(d-1))^((f>>(x&((1<<(d-1))-1)))&1))

def bits(x,d):return [(x>>(d-1-j))&1 for j in range(d)]

def win(b,i,h):
    z=0
    for j in range(h):z=(z<<1)|b[(i+j)%len(b)]
    return z

def trial(d,lengths):
    k=len(lengths); N=1<<d; f=RNG.getrandbits(N//2)
    words=[]; paths=[]; mids=[]; bridges=[]
    for r in lengths:
        t=r-2*d; v=RNG.randrange(N); w=RNG.randrange(N)
        p=[v]; b=bits(v,d)
        for _ in range(t):
            x=tf(d,f,p[-1]); p.append(x); b.append(x&1)
        b+=bits(w,d)
        assert len(b)==r
        ws=[win(b,i,d) for i in range(r)]
        ctx=[win(b,i+1,d-1) for i in range(r)]
        assert ws[:t+1]==p
        words.append(b); paths.append(p)
        mids.append(ctx[:t]); bridges.append(ctx[t:])
    middle_states=[x for p in paths for x in p]
    middle_bad=len(set(middle_states))!=len(middle_states)
    known=set(u for m in mids for u in m)
    add=[u for c in bridges for u in c]
    boundary_bad=(len(set(add))!=len(add) or bool(set(add)&known))
    good=not middle_bad and not boundary_bad
    C['trials']+=1; C[f'trials_k{k}']+=1
    if not good:return
    C['good']+=1; C[f'good_k{k}']+=1
    allstates=[win(b,i,d) for b in words for i in range(len(b))]
    assert len(set(allstates))==sum(lengths)
    fixed={}
    for b in words:
        for i in range(len(b)):
            u=win(b,i+1,d-1); z=b[i]^b[(i+d)%len(b)]
            if u in fixed:assert fixed[u]==z
            fixed[u]=z
    assert len(fixed)==len(known)+2*k*d
    g=f
    for u,z in fixed.items():
        if u in known:assert ((f>>u)&1)==z
        g=(g&~(1<<u))|(z<<u)
    for b in words:
        for i in range(len(b)):
            assert tf(d,g,win(b,i,d))==win(b,i+1,d)
    # Equality of binary exponents of the scaled ordinary and reference weights.
    vtotal=len(fixed); vmiddle=len(known)
    assert vtotal==vmiddle+2*k*d
    # All-open-then-force law on this good set samples kd bridge queries fairly.
    assert k*d+(vmiddle+k*d)==vtotal
    C['exact_good_weight_checks']+=1

def bridge_marginals():
    # Each bridge context is uniform conditional on an arbitrary fixed f.
    d=3; N=1<<d
    for f in range(1<<(N//2)):
        for t in (d,2*d,3*d,4*d):
            freq=[Counter() for _ in range(2*d)]
            for v in range(N):
                z=v
                for _ in range(t):z=tf(d,f,z)
                for w in range(N):
                    linear=bits(z,d)+bits(w,d)+bits(v,d)
                    for i in range(2*d):freq[i][win(linear,i+1,d-1)]+=1
            for c in freq:
                assert len(c)==N//2
                assert set(c.values())=={2*N}
                C['conditional_bridge_context_uniformity']+=1

if __name__=='__main__':
    bridge_marginals()
    for d,lengths,n in [(8,[24,40],2000),(9,[27,81],2000),
                        (10,[30,60,100],2500),(11,[33,66,132],2000),
                        (12,[36,72,120,240],2000), (14,[42,420],1000),
                        (16,[48,192,768],1000), (16,[48,96,160,320],1000)]:
        for _ in range(n):trial(d,lengths)
    result={'status':'all assertions passed','checks':dict(sorted(C.items())),
       'limitations':['Good-history identities only; no asymptotic constants are checked.',
       'The reference histories are seeded random samples.',
       'Conditional bridge marginal checks are exhaustive at d=3.']}
    Path('/mnt/data/thorp_multibridge_audit_results.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
