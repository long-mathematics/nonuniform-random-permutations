# Uniform multicycle moments for one Thorp shuffle
## Longest-last forcing, unequal lengths, and fixed-order Gaussian consequences

### Scope

This is a new research derivation extending the working notes
`thorp_first_moment_synthesis.md`, `thorp_entropy_audit_and_refinement.md`, and
`thorp_boundary_weighted_comparison.md`. The preceding comparable-length argument
forced all closures after exposing all open paths; that introduced a factor
`total length / shortest length`. Here only the longest cycle's closure is
forced at each induction step. The earlier cycles retain their scaled ordinary
measure. Its mass is a lower-order cycle moment, not one, and is kept explicitly.

The argument below proves the uniform upper estimate for arbitrary positive
lengths and a matching lower estimate for lengths at least 4d. It includes the
extension to every fixed number of cycles and the truncated functional
Erdos--Turan consequence for every fixed exponent below 2/3. It does not prove
full-order Erdos--Turan, a growing-order factorial-moment theorem, or
high-dimensional Poisson total-variation approximation beyond the birthday
range. The finite audits test the stated finite ingredients, not the
large-d entropy estimates or an external independent review.

Throughout,

\[
 N=2^d,\qquad
 T_f(x_1,\ldots,x_d)
 =(x_2,\ldots,x_d,x_1\oplus f(x_2,\ldots,x_d)),
\]

and the feedback values are independent fair bits chosen once. Write C_r for
the number of r-cycles. Entropies and the explicitly indicated log_2 are in
bits; logarithms in order statistics are natural.

## 1. Statement

For a list of positive lengths \(\mathbf r=(r_1,\ldots,r_k)\), put

\[
 L=\sum_{i=1}^k r_i,\qquad
 a_m=\#\{i:r_i=m\},\qquad
 Q_d(\mathbf r)=\left(\prod_{i=1}^k r_i\right)
 \mathbb E\prod_{m\ge1}(C_m)_{a_m},\qquad Q_d(\varnothing)=1.
\]

Fix k and 0<beta<2/3. Set

\[
 p_\beta=\frac{2}{2-3\beta},\qquad
 P_{k,\beta}(d)=d^{4k+1}+d(d\log_2d)^{kp_\beta}.
\]

**Theorem.** For all sufficiently large d, depending on k and beta:

* for all positive r_i with L<=N^beta,
  \[
  Q_d(\mathbf r)\le1+C_{k,\beta}P_{k,\beta}(d)\frac LN;
  \tag{1.1}
  \]
* if also every r_i>=4d, then
  \[
  1-C_k\frac{dL}{N}\le Q_d(\mathbf r)
  \le1+C_{k,\beta}P_{k,\beta}(d)\frac LN.
  \tag{1.2}
  \]

Constants are independent of all ratios r_i/r_j. In particular,

\[
 rs\,\mathbb E[C_r(C_s-\mathbf1_{\{r=s\}})]
 =1+O_\beta\!\left(P_{2,\beta}(d)\frac{r+s}{N}\right)
\]

uniformly for r,s>=4d and r+s<=N^beta. Equal lengths are covered by the falling
factorial, so the cycles are required to be distinct.

The displayed polynomial is deliberately not optimized. The conclusion is
uniform with exponentially small error in d on every fixed exponent range.

## 2. Exact cycle measures and weighted words

Choose k independent uniform roots, with replacement, independently of f. Let
E_r be the event that their cycles are distinct and have the prescribed lengths.
Then the finite measure

\[
 \mu_{\mathbf r}=N^k\mathbb P_0(\,\cdot\,,E_{\mathbf r})
\]

has total mass Q_d(r). An unrooted ordered cycle family has the same weight at
every choice of roots on its cycles.

Equivalently, prescribe k distinguished cyclic binary words with these lengths.
Let A_d require all their length-d windows to be distinct. A context is a
length-(d-1) window immediately following the initial bit of a state. On A_d,
a context has at most two occurrences. If a context occurs twice, the two
preceding bits differ and the two following bits differ, so the feedback
requirements are consistent. If m=L-v, with v distinct contexts, the family
occurs with probability 2^{-v}. Therefore

\[
 Q_d^{(m)}(\mathbf r)
 =2^{m-L}\#\{\text{valid rooted word families with m repeated contexts}\}.
 \tag{2.1}
\]

This identity counts all repeats, internal or between cycles. No
context-simplicity condition is imposed.

## 3. A global entropy tail for a fixed number of words

### 3.1 Type counting, including short component words

For a cyclic binary word of length n, let H_h be the entropy of its empirical
h-block distribution and delta_h=H_h-H_{h-1}. A fixed h-type contains at most

\[
 n\,2^{n\delta_h}
 \tag{3.1}
\]

rooted words. For h<=n, use the empirical order-(h-1) Markov chain: every word
of the type has probability at least n^{-1}2^{-n delta_h}, since its initial
block has mass at least 1/n and omitting wraparound transition factors only
increases the product.

The bound is also valid for h>n, a point needed for widely separated lengths.
An h-block then contains the entire cyclic word. A fixed h-type determines its
necklace, so at most n rooted words have the type. Also delta_h=0 once h-1>=n.

Writing M=2^h, the number of empirical types is at most

\[
 {n+M-1\choose M-1}\le[e(1+n/M)]^M.
 \tag{3.2}
\]

### 3.2 Mixture entropy

For a valid family, sample a position uniformly among its L positions and
read the resulting stationary binary process. All d-blocks are distinct, so

\[
 H_d=\log_2L,\qquad H_d-H_{d-1}=\frac{2m}{L}.
\]

Stationary conditional entropies decrease with block length. Thus

\[
 \delta_h\le\frac{H_h}{h}
 \le\frac{\log_2L-2m(d-h)/L}{h}.
 \tag{3.3}
\]

Let J identify the component circle and let X,Y be the preceding h-1 bits and
the final bit. Then

\[
 L\delta_h^{\rm mix}-\sum_i r_i\delta_h(w_i)
 =L I(Y;J\mid X)\ge0.
 \tag{3.4}
\]

This remains valid for any number of component circles and arbitrary lengths.
Applying (3.1)--(3.4), and bounding the rooted prefactor by L^k, yields

\[
 \log_2Q_d^{(m)}(\mathbf r)
 \le \frac{Lt}{h}
 +kM\log_2[e(1+L/M)]+k\log_2L-\kappa m,
 \tag{3.5}
\]

where

\[
 t=\log_2L-h,\qquad \kappa=\frac{2d-3h}{h}.
\]

### 3.3 The sparse threshold

Suppose d^4<=L<=N^beta, and put q=log_2 d and

\[
 h=\lfloor\log_2L-\log_2d-\log_2q\rfloor.
\]

For sufficiently large d, h>=2, h<=beta d,

\[
 \kappa\ge(2-3\beta)/\beta>0,
 \qquad kM\log_2[e(1+L/M)]\le 2kL/d.
\]

Let

\[
 F=Lt/h+2kL/d+k\log_2L,\qquad
 m_0=\left\lceil\frac{F+L/d}{\kappa}\right\rceil.
\]

Summing (3.5) gives

\[
 D_{\mathbf r}:=\sum_{m\ge m_0}Q_d^{(m)}(\mathbf r)
 \le C_\beta2^{-L/d}.
 \tag{3.6}
\]

Furthermore,

\[
 \frac{2dm_0}{L}
 \le p_\beta(\log_2d+\log_2\log_2d)+O_{k,\beta}(1).
 \tag{3.7}
\]

When r=max r_i, L/r<=k. Hence the closing penalty at the longest cycle's scale
satisfies

\[
 2^{2dm_0/r}\le C_{k,\beta}(d\log_2d)^{kp_\beta}.
 \tag{3.8}
\]

For L<d^4 no dense decomposition is necessary. Stationarity also gives

\[
 m\le\frac{L\log_2L}{2d},
\]

so, for any m_new<=m,

\[
 2^{2dm_{\rm new}/r}\le L^{L/r}\le L^k\le d^{4k}.
 \tag{3.9}
\]

In either case the needed sparse penalty is bounded by

\[
 H_{k,\beta}(d)=C_{k,\beta}\left[d^{4k}+(d\log_2d)^{kp_\beta}\right].
 \tag{3.10}
\]

It depends on k, not on the ratios between the component lengths.

## 4. Marked stopped collisions with earlier cycles present

Let a=(r_1,...,r_{k-1}), P=sum a_i, and let mu_a be its scaled ordinary cycle
measure. Conditional on the recorded rooted cycles, feedback values at all
unqueried contexts remain independent fair bits: specifying the recorded
cycles imposes exactly the feedback constraints along them.

Adjoin a new independent uniform root X and run its ordinary trajectory for n
steps. Retain it only if its first n+1 states are distinct and outside all the
earlier cycles. Let J_int count repeated contexts inside that prefix and
J_cross count prefix queries using contexts of earlier cycles. The latter
statistic may be bounded after dropping the retention restriction.

### 4.1 Internal contacts and marked switching

For h>0, the conjugate endpoint count must include the condition L_f(y)>h.
On an internal conjugate encounter of the new surviving path, both states of
the conjugate pair lie in a cycle disjoint from all earlier cycles. Their
context is therefore unused by every earlier cycle. Flipping its feedback
bit preserves all earlier marked cycles and splits off an h-cycle.

The resulting marked configurations are a subset of those counted by
Q_d(a,h). Stationarity of the new uniform root then gives

\[
 \mathbb E_{\mu_a,X}J_{\rm int}
 \le\frac1N\sum_{h=1}^{n-1}(n-h)Q_d(a,h).
 \tag{4.1}
\]

This is not a conditional-uniformity assertion about f under mu_a. It follows
from the feedback-flip bijection while keeping the previously selected cycles
marked. The survival and disjointness restrictions ensure the flip leaves those
marks unchanged. Sorting the list (a,h) is permitted because Q is symmetric.

### 4.2 Cross contacts

For fixed f and fixed earlier cycles, every iterate of X is uniform because
T_f is a permutation. The earlier cycles use at most P contexts. Each context
has exactly two possible preceding states, so

\[
 \mathbb E_{\mu_a,X}J_{\rm cross}
 \le\frac{2nP}{N}Q_d(a).
 \tag{4.2}
\]

Consequently the ordinary open-repeat statistic J satisfies

\[
 \mathbb E J\le
 \frac1N\sum_{h=1}^{n-1}(n-h)Q_d(a,h)
 +\frac{2nP}{N}Q_d(a).
 \tag{4.3}
\]

The first term involves the same number of cycles but strictly smaller total
length. The second involves one fewer cycle. This is the induction structure.

## 5. Force only the longest cycle's closure

Sort r_1<=...<=r_k=r. Keep the earlier cycles under mu_a. Starting from a new
uniform root, expose r-d ordinary open steps, then force the final d outputs
to equal the initial state. Never change an already prescribed feedback value.
Success requires first return at exactly r and disjointness from all earlier
cycles. Complete unqueried feedback values fairly.

Denote this finite successful measure by nu_{a;r}. Its mass is at most Q_d(a),
not necessarily at most one. On successful histories,

\[
 d\nu_{a;r}=2^{-K}d\mu_{a,r},
 \tag{5.1}
\]

where K counts closing queries already known either from earlier cycles or
from the current open path.

For a fixed full cycle family, let m_new count all repeats involving the last
cycle: internal repeats plus contexts it shares with earlier cycles. Earlier
cycles' internal repeats are not counted in m_new. If J counts reused queries
in the last cycle's open part (with earlier contexts known at time zero), then

\[
 J+K=m_{\rm new}.
 \tag{5.2}
\]

Average only the root of the last cycle. A shared context belongs to its
closing part with probability d/r; an internal repeated context contributes
with probability at most 2d/r. Thus

\[
 \mathbb E_{\rm root}K\le2dm_{\rm new}/r,
 \quad \mathbb E_{\rm root}J\ge a_rm_{\rm new},
 \quad a_r=1-2d/r.
\]

The function j -> j 2^{j-m_new} is increasing and convex for j>=0. Therefore

\[
 \mathbb E_{\rm root}[J2^{-K}]
 \ge a_rm_{\rm new}2^{-2dm_{\rm new}/r}.
 \tag{5.3}
\]

On the sparse class, (3.8) or (3.9) bounds the inverse factor by H_{k,beta}.
The forced open part has exactly the ordinary mu_a-plus-uniform-root law;
success only restricts it. Integrating (5.3), and using 1-2^{-K}<=K, gives

\[
\begin{split}
0\le Q_d(a,r)-\nu_{a;r}(\Omega)
&\le\frac{2d}{r}\int_{\rm sparse}m_{\rm new}\,d\mu_{a,r}+D_{a,r}\\
&\le\frac{2dH_{k,\beta}}{r-2d}\mathbb E J+D_{a,r}.
\end{split}
\tag{5.4}
\]

Take r>=4d and n=r-d. Combining (4.3), (5.4), and
nu_{a;r}(Omega)<=Q_d(a), yields the key finite recurrence

\[
\boxed{
Q_d(a,r)\le Q_d(a)
+\frac{2dH_{k,\beta}}{r-2d}
 \left[
 \frac1N\sum_{h=1}^{n-1}(n-h)Q_d(a,h)
 +\frac{2nP}{N}Q_d(a)
 \right]+D_{a,r}.
}
\tag{5.5}
\]

D=0 for total length below d^4; otherwise it is bounded by (3.6).

No long cycle is charged at a shorter cycle's rate. Prior cycles remain under
their ordinary finite measure, rather than being incorrectly treated as an
unbiased probability law after earlier forced closures.

## 6. Close the upper induction

### 6.1 Base: all lengths below 4d

Let B mean that every prescribed cyclic word is primitive and no two words
represent the same necklace. A_d implies B. On B with no repeated contexts,
the weighted integrand is exactly one.

For two distinct positions,

\[
 \mathbb P(B\text{ and their }(d-1)\text{-contexts agree})\le2^{-(d-1)}.
\]

For positions on the same circle of length n and displacement a, the equality
constraints have rank min(d-1,n-gcd(n,a)); if this rank is less than d-1,
the constraints force a smaller period, impossible on B. For different circles,
the first r+s-gcd(r,s) equality edges form a forest; past this point equality
forces nonprimitivity or the same necklace. These facts prove the displayed
bound even for wrapped contexts.

A union bound, together with m<=L log_2 L/(2d), implies

\[
 Q_d(\mathbf r)\le1+\frac{L^{2k+2}}N,
 \qquad \max_i r_i<4d,\quad L<4kd.
 \tag{6.1}
\]

### 6.2 Crude bound

Induct first on the number of cycles k, then strongly on total length L for
fixed k. The target crude bound is Q_d(r)<=2^k. The base (6.1) holds for large d.
When r=max r_i>=4d, all same-k moments in (5.5) have total length P+h<L.
The lower-order moment is bounded by 2^{k-1}. Therefore

\[
 Q_d(a,r)\le2^{k-1}
 +C_k dH_{k,\beta}(d)\frac LN+D_{a,r}.
\]

The extra terms tend to zero uniformly for L<=N^beta, since H is polynomial
and beta<1. Thus they fit within the fixed gap from 2^{k-1} to 2^k.
This closes the induction, including moment lists that contain very short
components. In particular, Q_d(h)<=2 for all h<=N^beta.

### 6.3 Sharp constant

Substitute the crude bounds back into (5.5):

\[
 Q_d(a,r)\le Q_d(a)+C_{k,\beta}dH_{k,\beta}(d)\frac LN+D_{a,r}.
\]

Repeatedly remove a longest component. There are at most k steps. The base
(6.1) costs at most a polynomial times 1/N, absorbed by P_{k,beta} L/N.
For L>=d^4 the dense error is at most C_beta 2^{-d^3}, also absorbed.
This proves (1.1).

## 7. A matching lower bound from several middle-first bridges

Only the one-cycle bound Q_d(h)<=2 is needed in this section.

For an ordinary trajectory of n>=d steps from a uniform root, let R_{n,d}
mean that some query in its final d steps repeats an earlier context. The
stopped conjugate-switch identity and a union bound over time separations give

\[
 \mathbb P(R_{n,d})\le\frac{d+1}{N}\sum_{h\le n}Q_d(h)
 \le\frac{2(d+1)n}{N}.
 \tag{7.1}
\]

The event of a prior return costs (sum_{h<=n}Q_d(h))/N; on survival a repeated
context is a conjugate encounter, and each separation appears at most d times
in the terminal query block. Coupling the last d fresh outputs to fair bits
also gives

\[
 d_{\rm TV}(\mathcal L(X_0,X_n),U_N\otimes U_N)
 \le\frac{2(d+1)n}{N}.
 \tag{7.2}
\]

Coordinate reversal conjugates the inverse Thorp permutation to the same model
with its feedback arguments reversed, so these estimates hold backwards too.

### 7.1 Reference construction

Assume all r_i>=4d and put t_i=r_i-2d. In a common ordinary feedback environment,
choose independent uniform roots v_i and run middle paths of t_i steps to z_i.
Independently choose uniform w_i. Add the two unique d-step shift paths

\[
 z_i\longrightarrow w_i\longrightarrow v_i.
\]

Let G require all middle states to be distinct, within and between paths, and
all 2kd added query contexts to be mutually distinct and absent from every
middle queried context. On G assign the fresh feedback values to realize the
added outputs and complete all remaining values fairly. This produces k
disjoint cycles of the required lengths.

### 7.2 Failure bounds

Internal failure of a middle path costs at most 2t_i/N.

For different middle paths of lengths t_i,t_j, conditional on any fixed f,
an intersection entails

\[
 v_j=T_f^{a-b}v_i,
 \qquad 0\le a\le t_i,\quad0\le b\le t_j.
\]

There are at most t_i+t_j+1 distinct offsets. Thus

\[
 \mathbb P(\text{middle }i\text{ meets middle }j\mid f)
 \le(t_i+t_j+1)/N.
 \tag{7.3}
\]

There is no t_i t_j/N loss here.

For each forward added path, couple until its first query already known from
the middles or from its own preceding added queries. Conditional on the middle
traces, unused feedback values are still independent fair bits. Self-contacts
are bounded by (7.1). Contacts with another middle are bounded by 2d t_j/N:
conditional on f, the two roots are independent uniform, so every specified
pair of query contexts agrees with probability 2/N. For the other added path,
explore backwards and use exactly the same argument. Summing costs O_k(dL/N).

For the two added paths belonging to the same cycle, their possible cross
contacts depend only on z_i,w_i,v_i. By (7.2) this triple is within
2(d+1)t_i/N of three independent uniform states. Under the independent law,
z_i w_i v_i is a linear iid binary word; each of the d^2 possible cross-window
matches has probability 2/N, including overlapping windows. This again sums
to O_k(dL/N).

For added paths belonging to different cycles, no endpoint approximation is
needed. Conditional on f, the pairs (v_i,w_i) are independent across i, z_i is
uniform, and each individual added context is uniform. Thus each cross-cycle
pair of added contexts agrees with probability 2/N. There are O(k^2d^2) such
pairs, costing O(k^2d^2/N), absorbed into O_k(dL/N).

All estimates are unconditional union bounds; the failure events are not
assumed independent. Together,

\[
 \mathbb P_{\rm ref}(G)\ge1-C_k dL/N.
 \tag{7.4}
\]

### 7.3 Exact good-history weight

Fix the middle traces, whose queried contexts number v_M, and the words w_i.
The ordinary root-and-middle probability contains N^{-k}2^{-v_M}. On G the
2kd prescribed fresh outputs have probability N^{-2k}; scaling the ordinary
law by N^k leaves weight 2^{-(v_M+2kd)}. The reference chooses all w_i with
probability N^{-k}, giving the same weight N^{-2k}2^{-v_M}.

Thus the scaled ordinary cycle measure equals the reference measure on G,
including the same uniform completion of unused feedback values. Therefore

\[
 Q_d(\mathbf r)\ge\mathbb P_{\rm ref}(G)\ge1-C_kdL/N.
\]

This proves the lower half of (1.2). It needs neither conditional independence
of endpoints given all other traces nor a joint-collision moment theorem.

## 8. Fixed-order moments and the truncated Gaussian field

Fix 0<alpha<2/3 and choose beta strictly between alpha and 2/3. Let b=floor(N^alpha)
and ell=log N. For every fixed moment order m and all sufficiently large d,
all lists of at most m lengths bounded by b have total length <=N^beta.
For lengths in [4d,b], Theorem (1.2) gives

\[
 \max_{1\le j\le m}\ \sup_{4d\le r_1,\ldots,r_j\le b}
 |Q_d(r_1,\ldots,r_j)-1|
 \le \varepsilon_{d,m},\qquad
 \varepsilon_{d,m}=d^{O_{m,\beta}(1)}N^{\alpha-1}.
 \tag{8.1}
\]

This is smaller than every negative power of d for fixed m.

Let Z_r, 4d<=r<=b, be independent Poisson variables of means 1/r. Their normalized
factorial moments Q are exactly one. Ordinary moments of additive cycle
statistics expand over partitions of their selected cycle occurrences into
groups that refer to the same cycle. Each block contributes one harmonic
summation. For logarithmic weights, a block of multiplicity a contributes at
most

\[
 \sum_{r\le b}(\log r)^a/r=O_a(\ell^{a+1}).
\]

Consequently the error in a fixed raw m-th moment of the logarithmic product
is O_m(epsilon_{d,m} ell^{2m}). Centering and Gaussian normalization multiply
this only by further powers of ell. All normalized moment errors vanish.
The same argument applies to arbitrary finite collections of count and
log-product increments. The corresponding Poisson statistics have Gaussian
limits and moment-determinate limiting distributions.

### Tightness, rather than just finite-dimensional convergence

Use a grid with cutoffs approximately e^j, equivalently u=j/ell, and linearly
interpolate the centered normalized processes. For a grid interval of m>=1
steps, its Poisson intensity is O(m). The fourth centered moments of the
normalized count increment, and of its normalized log-weighted analogue, are
at most C(m^2+m)/ell^2. By (8.1) with moment order four, the actual fourth
moments have an exponentially small extra error, absorbed into C(m/ell)^2.

Linear interpolation gives a uniform fourth-moment continuity bound
C|u-v|^2, also within individual grid cells. For the original step processes,
a single grid bin has uniformly bounded fourth moment of its cycle count
(the upper moment theorem for orders <=4 suffices). A union bound over O(ell)
bins shows that the maximum bin count divided by sqrt(ell) tends to zero in
probability. The same controls the normalized log-product oscillation because
log r<=alpha ell. Thus the step processes and their tight interpolations are
uniformly close in probability.

Below length 4d, Q_d(r)<=2 implies expected count O(log d) and expected
log-product O((log d)^2). Both vanish at their respective normalizations.
This also handles the initial interval near u=0. Centering by exact harmonic
sums or by the displayed polynomial centerings differs by a uniformly negligible
quantity.

Therefore, with

\[
 K_d(u)=\sum_{r\le N^u}C_r,\qquad
 B_d(u)=\sum_{r\le N^u}C_r\log r,
\]

we obtain convergence in D([0,alpha],R^2), with continuous limiting paths:

\[
 \left(
 \frac{K_d(u)-u\ell}{\sqrt\ell},\quad
 \frac{B_d(u)-\tfrac12u^2\ell^2}{\sqrt{\ell^3/3}}
 \right)
 \Longrightarrow
 \left(W(u),\sqrt3\int_0^u t\,dW(t)\right).
 \tag{8.2}
\]

No process-level Poisson total-variation approximation is asserted here. Fixed
orders, with superpolynomially small errors for each order, are sufficient for
this moment-and-tightness argument.

## 9. Product to LCM

For all r,s<=b, the all-positive-length upper theorem gives, for large d,

\[
 \mathbb EC_r\le2/r,\qquad
 \mathbb E[C_r(C_s-\mathbf1_{r=s})]\le2/(rs).
\]

Let D_m=sum_{m|r,r<=b} C_r. The exact arithmetic identity is

\[
 B_d(\alpha)-\log\operatorname{lcm}\{r\le b:C_r>0\}
 =\sum_{m\le b}\Lambda(m)(D_m-1)_+.
\]

The preceding harmonic bounds imply

\[
 \mathbb E(D_m-1)_+
 \le\min\left\{\frac{2H_{\lfloor b/m\rfloor}}m,
 \frac{H_{\lfloor b/m\rfloor}^2}{m^2}\right\}.
\]

Split at m=log b and use Lambda(m)<=log m. The expected discrepancy is

\[
 O\big(\log b\,(\log\log b)^2\big)=o(\ell^{3/2}).
\]

The discrepancy is nondecreasing with the cutoff, so the bound is uniform
on 0<=u<=alpha. Markov's inequality transfers (8.2) from B_d(u) to

\[
 O_d(u)=\log\operatorname{lcm}\{r\le N^u:C_r>0\}.
\]

In particular, with b=floor(N^alpha),

\[
 \boxed{
 \frac{\log\operatorname{lcm}\{r\le b:C_r>0\}
       -\tfrac12(\log b)^2}{\sqrt{(\log b)^3/3}}
 \Longrightarrow\mathcal N(0,1),\qquad 0<\alpha<2/3.
 }
\]

This is a truncated theorem. No estimate above uses or proves a dense-tail
bound at exponent 2/3 or beyond it, where the coefficient kappa in (3.5)
ceases to give the required saving.

## 10. Finite checks actually executed

`thorp_multiscale_cycle_audit.py` checks exact integer inequalities. It fully
enumerates all 272 feedback functions in dimensions 3 and 4 for marked aggregate
bounds and partial-forcing mass/collision comparisons. Additional seeded
samples of 512 feedback environments in dimensions 5 and 6 test deterministic
family inequalities only. It includes families of one through four cycles,
with unequal lengths and short components smaller than the entropy block size.
The recorded JSON contains the precise counts; all assertions passed.

The executed checks include:

* 873 marked aggregate switching inequalities;
* 175 partial-forcing mass and ordinary-open-collision inequalities;
* 243,751 rooted accounting/likelihood checks;
* 9,998 convexity checks;
* 53,733 integer entropy/mixture checks, including 32,085 cases with a component
  shorter than the block size;
* 262 complete short-word type classes for h>n.

`thorp_multibridge_audit.py` checks exact conditional bridge-context uniformity
in dimension 3 and the deterministic construction on 13,500 seeded reference
samples in dimensions 8 through 16. There were 852 nonempty good histories:
233 with two cycles, 265 with three, and 354 with four. All corresponding
fresh-context, disjoint-state, completed-permutation, and good-weight identities
passed. These samples are not a proof or estimate of the asymptotic good-event
probability; that probability is bounded analytically in Section 7.

Files:

* `thorp_multiscale_cycle_audit.py`
* `thorp_multiscale_cycle_audit_results.json`
* `thorp_multibridge_audit.py`
* `thorp_multibridge_audit_results.json`

The argument is a working proof with transparent finite checks, not a claim of
formal verification or independent peer review. In particular, the full
one-shuffle Erdos--Turan conjecture remains beyond the range proved here.
