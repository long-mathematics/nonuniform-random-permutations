---
title: "Mesoscopic cycle universality for a single Thorp shuffle"
subtitle: "Uniform multicycle moments and the truncated functional Erdős–Turán law"
author: "Christopher D. Long"
date: "9 October 2026 — reviewed proof, version 1.0"
fontsize: 11pt
geometry: margin=1in
colorlinks: false
---

## Abstract and scope

For a uniformly chosen binary noncoalescing feedback shift register of width
$d$, we prove uniform joint cycle factorial-moment estimates for every fixed
number of cycles whose total length is at most $N^\beta$, where $N=2^d$ and
$\beta<2/3$. The estimates are independent of the ratios of the prescribed
lengths. They imply the joint functional Gaussian limit for cycle counts and
logarithmic truncated permutation order on every fixed interval
$[0,\alpha]$, $\alpha<2/3$.

The proof uses an exact weighted-word identity, a finite-measure version of
longest-last forced closure, a stopped marked switching inequality, cyclic
empirical-type entropy bounds, and a multicycle middle-first bridge. The
feedback function is sampled once and reused. No independent-round mixing
result, protected-cut lemma, or Poisson–Dirichlet limit is used in the proof.

This is a reviewed research proof, not a claim of formal verification or
independent peer review. The accompanying audit report records the review,
reproduced tests, new tests, changes from the supplied manuscript, and limits
of the verification. The result is truncated: the endpoint $2/3$, the full
permutation-order conjecture, growing-order factorial moments, and a
growing-dimensional Poisson total-variation approximation beyond the birthday
range are not asserted.

Throughout,
\[
 N=2^d,\qquad
 T_f(x_1,\ldots,x_d)
 =(x_2,\ldots,x_d,x_1\oplus f(x_2,\ldots,x_d)),
\]
where the $N/2$ feedback values are independent fair bits. Write $C_r$ for the
number of $r$-cycles, $u(x)$ for the last $d-1$ bits of a state, and $\bar x$
for the state obtained by flipping its first bit. Entropies and $\log_2$ are
in bits; logarithms in order statistics are natural. The notation $(z)_a$
means a falling factorial, and the LCM of an empty set is one.

## 1. Statement

For a list of positive lengths \(\mathbf r=(r_1,\ldots,r_k)\), put

\[
 L=\sum_{i=1}^k r_i,\qquad
 a_m=\#\{i:r_i=m\},\qquad
 Q_d(\mathbf r)=\left(\prod_{i=1}^k r_i\right)
 \mathbb E\prod_{m\ge1}(C_m)_{a_m},\qquad Q_d(\varnothing)=1.
\]

Fix an integer $k\ge1$ and a real $0<\beta<2/3$. Set

\[
 p_\beta=\frac{2}{2-3\beta},\qquad
 P_{k,\beta}(d)=d^{4k+1}+d(d\log_2d)^{kp_\beta}.
\]

**Theorem.** For all sufficiently large $d$, depending on $k$ and $\beta$:

* for all positive $r_i$ with $L\le N^\beta$,
  \[
  Q_d(\mathbf r)\le1+C_{k,\beta}P_{k,\beta}(d)\frac LN;
  \tag{1.1}
  \]
* if also every $r_i\ge4d$, then
  \[
  1-C_k\frac{dL}{N}\le Q_d(\mathbf r)
  \le1+C_{k,\beta}P_{k,\beta}(d)\frac LN.
  \tag{1.2}
  \]

Constants are independent of all ratios $r_i/r_j$. In particular,

\[
 rs\,\mathbb E[C_r(C_s-\mathbf1_{\{r=s\}})]
 =1+O_\beta\!\left(P_{2,\beta}(d)\frac{r+s}{N}\right)
\]

uniformly for $r,s\ge4d$ and $r+s\le N^\beta$. Equal lengths are covered by the falling
factorial, so the cycles are required to be distinct.

The displayed growth factor is deliberately not optimized. The conclusion is
uniform with exponentially small error in $d$ on every fixed exponent range.

### Functional consequence

Fix $0<\alpha<2/3$, put $\ell=\log N$, and define, for $0\le u\le\alpha$,
\[
 K_d(u)=\sum_{r\le\lfloor N^u\rfloor}C_r,
 \qquad
 O_d(u)=\log\operatorname{lcm}\{r\le\lfloor N^u\rfloor:C_r>0\}.
\]
Then, in $D([0,\alpha],\mathbb R^2)$ with its Skorokhod $J_1$ topology,
\[
 \left(
 \frac{K_d(u)-u\ell}{\sqrt\ell},
 \frac{O_d(u)-\tfrac12u^2\ell^2}{\sqrt{\ell^3/3}}
 \right)_{0\le u\le\alpha}
 \ \Longrightarrow\
 \left(W(u),\sqrt3\int_0^u t\,dW(t)\right)_{0\le u\le\alpha}.
 \tag{1.3}
\]
Here $W$ is one standard Brownian motion, shared by both coordinates. In
particular, for $b=\lfloor N^\alpha\rfloor$,
\[
 \frac{\log\operatorname{lcm}\{r\le b:C_r>0\}
       -\tfrac12(\log b)^2}{\sqrt{(\log b)^3/3}}
 \ \Longrightarrow\ \mathcal N(0,1).
 \tag{1.4}
\]
The proof of the functional consequence, including tightness, is given in
Sections 8–9. The parameters $k,\beta,\alpha$ are fixed before $d\to\infty$;
no uniform assertion as $k\to\infty$ or $\beta\uparrow2/3$ is made.

## 2. Exact cycle measures and weighted words

Choose $k$ independent uniform roots, with replacement, independently of $f$. Let
$E_{\mathbf r}$ be the event that their cycles are distinct and have the prescribed lengths.
Then the finite measure

\[
 \mu_{\mathbf r}=N^k\mathbb P_0(\,\cdot\,,E_{\mathbf r})
\]

has total mass $Q_d(\mathbf r)$. An unrooted ordered cycle family has the same weight at
every choice of roots on its cycles.

Equivalently, prescribe $k$ distinguished cyclic binary words with these lengths.
Let $A_d$ require all their length-$d$ windows to be distinct. A context is a
length-($d$-1) window immediately following the initial bit of a state. On $A_d$,
a context has at most two occurrences. If a context occurs twice, the two
preceding bits differ and the two following bits differ, so the feedback
requirements are consistent. If $m=L-v$, with $v$ distinct contexts, the family
occurs with probability $2^{-v}$. Therefore

\[
 Q_d^{(m)}(\mathbf r)
 =2^{m-L}\#\{\text{valid rooted word families with m repeated contexts}\}.
 \tag{2.1}
\]

This identity counts all repeats, internal or between cycles. No
context-simplicity condition is imposed.

## 3. A global entropy tail for a fixed number of words

### 3.1 Type counting, including short component words

For a cyclic binary word of length $n$, let $H_h$ be the entropy of its empirical
$h$-block distribution and $\delta_h=H_h-H_{h-1}$. A fixed $h$-type contains at most

\[
 n\,2^{n\delta_h}
 \tag{3.1}
\]

rooted words. For $h\le n$, use the empirical order-$(h-1)$ Markov chain: every word
of the type has probability at least $n^{-1}2^{-n\delta_h}$, since its initial
block has mass at least $1/n$ and omitting wraparound transition factors only
increases the product.

The bound is also valid for $h>n$, a point needed for widely separated lengths.
An $h$-block then contains the entire cyclic word. A fixed $h$-type determines its
necklace, so at most $n$ rooted words have the type. Also $\delta_h=0$ once $h-1\ge n$.

Writing $M=2^h$, the number of empirical types is at most

\[
 \binom{n+M-1}{M-1}\le[e(1+n/M)]^M.
 \tag{3.2}
\]

Indeed, the nonnegative block counts sum to $n$. Stars and bars gives the
first bound in (3.2); then
$\binom{n+M-1}{M-1}\le\binom{n+M}{M}\le[e(n+M)/M]^M$.
No assumption that different component types are independent is used.

### 3.2 Mixture entropy

For a valid family, sample a position uniformly among its $L$ positions and
read the resulting stationary binary process. All $d$-blocks are distinct, so

\[
 H_d=\log_2L,\qquad H_d-H_{d-1}=\frac{2m}{L}.
\]

Stationary conditional entropies decrease with block length. Thus

\[
 \delta_h\le\frac{H_h}{h}
 \le\frac{\log_2L-2m(d-h)/L}{h}.
 \tag{3.3}
\]

Let $J$ identify the component circle and let $X$,$Y$ be the preceding $h$-1 bits and
the final bit. Then

\[
 L\delta_h^{\rm mix}-\sum_i r_i\delta_h(w_i)
 =L I(Y;J\mid X)\ge0.
 \tag{3.4}
\]

This remains valid for any number of component circles and arbitrary lengths.
Applying (3.1)--(3.4), and bounding the rooted prefactor by $L^k$, yields

\[
 \log_2Q_d^{(m)}(\mathbf r)
 \le \frac{Lt}{h}
 +kM\log_2[e(1+L/M)]+k\log_2L-\kappa m,
 \tag{3.5}
\]

where

\[
 t=\log_2L-h,\qquad \kappa=\frac{2d-3h}{h}.
\]

### 3.3 The sparse threshold

Suppose $d^4\le L\le N^\beta$, and put $q=\log_2d$ and

\[
 h=\lfloor\log_2L-\log_2d-\log_2q\rfloor.
\]

For sufficiently large $d$, $h\ge2$ and $h\le\beta d$,

\[
 \kappa\ge(2-3\beta)/\beta>0,
 \qquad kM\log_2[e(1+L/M)]\le 2kL/d.
\]

Let

\[
 F=Lt/h+2kL/d+k\log_2L,\qquad
 m_0=\left\lceil\frac{F+L/d}{\kappa}\right\rceil.
\]

Summing (3.5) gives

\[
 D_{\mathbf r}:=\sum_{m\ge m_0}Q_d^{(m)}(\mathbf r)
 \le C_\beta2^{-L/d}.
 \tag{3.6}
\]

Furthermore,

\[
 \frac{2dm_0}{L}
 \le p_\beta(\log_2d+\log_2\log_2d)+O_{k,\beta}(1).
 \tag{3.7}
\]

For clarity, the algebra behind (3.7) is
\[
 \frac{2dm_0}{L}
 \le \frac{2d}{2d-3h}
 \left[t+(2k+1)\frac hd+\frac{kh\log_2L}{L}\right]
 +\frac{2d}{L}.
\]
The leading multiplier is at most $p_\beta$;
$t\in[\log_2d+\log_2\log_2d,\,
\log_2d+\log_2\log_2d+1)$, $h/d\le\beta$, and
$h\log_2L/L=O_\beta(d^{-2})$ because $L\ge d^4$.
Also, summation in (3.6) uses the finite positive lower bound on $\kappa$:
$\sum_{m\ge m_0}2^{F-\kappa m}\le
2^{-L/d}/(1-2^{-\kappa})$.

When $r=\max_i r_i$, $L/r\le k$. Hence the closing penalty at the longest cycle'$s$ scale
satisfies

\[
 2^{2dm_0/r}\le C_{k,\beta}(d\log_2d)^{kp_\beta}.
 \tag{3.8}
\]

For $L<d^4$ no dense decomposition is necessary. Stationarity also gives

\[
 m\le\frac{L\log_2L}{2d},
\]

so, for any $m_{\rm new}\le m$,

\[
 2^{2dm_{\rm new}/r}\le L^{L/r}\le L^k\le d^{4k}.
 \tag{3.9}
\]

In either case the needed sparse penalty is bounded by

\[
 H_{k,\beta}(d)=C_{k,\beta}\left[d^{4k}+(d\log_2d)^{kp_\beta}\right].
 \tag{3.10}
\]

It depends on $k$, not on the ratios between the component lengths.

## 4. Marked stopped collisions with earlier cycles present

Let $\mathbf a=(r_1,\ldots,r_{k-1})$, $P=\sum_i a_i$, and let $\mu_{\mathbf a}$ be its scaled ordinary cycle
measure. Conditional on the recorded rooted cycles, feedback values at all
unqueried contexts remain independent fair bits: specifying the recorded
cycles imposes exactly the feedback constraints along them.

Adjoin a new independent uniform root $X$ and run its ordinary trajectory for $n$
steps. Retain it only if its first $n+1$ states are distinct and outside all the
earlier cycles. Let $J_{\rm int}$ count repeated contexts inside that prefix and
$J_{\rm cross}$ count prefix queries using contexts of earlier cycles. The latter
statistic may be bounded after dropping the retention restriction.

### 4.1 Internal contacts and marked switching

For $h>0$, the conjugate endpoint count must include the condition $L_f(y)>h$.
On an internal conjugate encounter of the new surviving path, both states of
the conjugate pair lie in a cycle disjoint from all earlier cycles. Their
context is therefore unused by every earlier cycle. Flipping its feedback
bit preserves all earlier marked cycles and splits off an $h$-cycle.

The resulting marked configurations are a subset of those counted by
$Q_d(\mathbf a,h)$. Stationarity of the new uniform root then gives

\[
 \mathbb E_{\mu_a,X}J_{\rm int}
 \le\frac1N\sum_{h=1}^{n-1}(n-h)Q_d(a,h).
 \tag{4.1}
\]

This is not a conditional-uniformity assertion about $f$ under $\mu_{\mathbf a}$. It follows
from the feedback-flip bijection while keeping the previously selected cycles
marked. The survival and disjointness restrictions ensure the flip leaves those
marks unchanged. Sorting the list (a,$h$) is permitted because $Q$ is symmetric.

Here is the normalization and bijection in (4.1). Write
$\mathcal C_f(y)$ for the cycle containing $y$ and $A$ for the union of the
previously marked cycles. Feedback-bit switching gives
\[
 \int\!\mu_{\mathbf a}(d(f,\text{marks}))
 \sum_{\substack{y:T_f^hy=\bar y,\ L_f(y)>h\\
                  \mathcal C_f(y)\cap A=\varnothing}}1
 \le Q_d(\mathbf a,h).
 \tag{4.1a}
\]
To see this, flip the bit at $u(y)$. In the new permutation the cycle containing
$\bar y$ has length $h$, and $y$ is outside it. All earlier marked cycles,
including their roots, are unchanged. The map is injective: from the new
marked $h$-cycle rooted at $\bar y$, recover $y$, flip the same bit, and
recover the original configuration. Counting all marked $h$-cycles can only
enlarge the image. The uniform feedback law is invariant under this flip.
The factor $h$ in $Q_d(\mathbf a,h)$ counts its possible new roots, including
when $h$ equals one of the earlier lengths.

For a retained prefix and query times $i<j$, take $y=T_f^iX$ and $h=j-i$.
Conditional on $f$ and the earlier marks, $y$ is uniform. The retained prefix
is in a cycle disjoint from $A$; disjointness of a prefix from $A$ implies this
because $A$ is a union of complete cycles. It also has $L_f(y)>n>h$.
Dropping the stronger retention conditions and applying (4.1a) gives
$Q_d(\mathbf a,h)/N$ for each pair. There are $n-h$ query pairs with separation
$h$, proving (4.1). No unconditioned stationarity assertion is substituted
for this marked calculation.

### 4.2 Cross contacts

For fixed $f$ and fixed earlier cycles, every iterate of $X$ is uniform because
$T_f$ is a permutation. The earlier cycles use at most $P$ contexts. Each context
has exactly two possible preceding states, so

\[
 \mathbb E_{\mu_a,X}J_{\rm cross}
 \le\frac{2nP}{N}Q_d(a).
 \tag{4.2}
\]

On a retained prefix, each context occurs at most twice across its query
states and the earlier cycles: a context has only two preceding states, and
all these states are distinct. Hence a prefix query cannot simultaneously
repeat an earlier prefix query and a context in the marked cycles. Thus the
reused-query count is exactly $J=J_{\rm int}+J_{\rm cross}$ on retained
histories. Both quantities are set to zero on discarded histories; only the
cross bound is enlarged by dropping retention.

Consequently the ordinary open-repeat statistic $J$ satisfies

\[
 \mathbb E J\le
 \frac1N\sum_{h=1}^{n-1}(n-h)Q_d(a,h)
 +\frac{2nP}{N}Q_d(a).
 \tag{4.3}
\]

The first term involves the same number of cycles but strictly smaller total
length. The second involves one fewer cycle. This is the induction structure.

## 5. Force only the longest cycle'$s$ closure

Sort $r_1\le\cdots\le r_k=r$. Keep the earlier cycles under $\mu_{\mathbf a}$. Starting from a new
uniform root, expose $r-d$ ordinary open steps, then force the final $d$ outputs
to equal the initial state. Never change an already prescribed feedback value.
Success requires first return at exactly $r$ and disjointness from all earlier
cycles. Complete unqueried feedback values fairly.

Operationally, first sample the *recorded* marked-cycle histories from the
projection of $\mu_{\mathbf a}$, which is a finite measure. Sample only the
still-unqueried feedback values as the new trajectory needs them, and
complete the remaining values at the end. This avoids treating the biased
law after an earlier forced closure as an ordinary feedback law. Every
previously selected cycle constrains only its own queried contexts.

Denote this finite successful measure by $\nu_{\mathbf a;r}$. Its mass is at most $Q_d(\mathbf a)$,
not necessarily at most one. On successful histories,

\[
 d\nu_{a;r}=2^{-K}d\mu_{a,r},
 \tag{5.1}
\]

For an atom with $v_{\rm old}$ old contexts and $v$ contexts in the completed
family, the scaled ordinary word weight is $2^{-v}$. The forced construction
samples the new root with factor $N^{-1}$ and samples only
$v-v_{\rm old}-(d-K)$ additional feedback bits fairly. Its weight is therefore
$2^{-v_{\rm old}}N^{-1}
2^{-[v-v_{\rm old}-(d-K)]}=2^{-v-K}$.
Unused fair completion is identical. This proves (5.1) at the atom level.

where $K$ counts closing queries already known either from earlier cycles or
from the current open path.

For a fixed full cycle family, let $m_{\rm new}$ count all repeats involving the last
cycle: internal repeats plus contexts it shares with earlier cycles. Earlier
cycles' internal repeats are not counted in $m_{\rm new}$. If $J$ counts reused queries
in the last cycle'$s$ open part (with earlier contexts known at time zero), then

\[
 J+K=m_{\rm new}.
 \tag{5.2}
\]

Average only the root of the last cycle. A shared context belongs to its
closing part with probability $d$/$r$; an internal repeated context contributes
with probability at most 2d/$r$. Thus

\[
 \mathbb E_{\rm root}K\le2dm_{\rm new}/r,
 \quad \mathbb E_{\rm root}J\ge a_rm_{\rm new},
 \quad a_r=1-2d/r.
\]

The function $j\mapsto j2^{j-m_{\rm new}}$ is increasing and convex for $j\ge0$. Therefore

\[
 \mathbb E_{\rm root}[J2^{-K}]
 \ge a_rm_{\rm new}2^{-2dm_{\rm new}/r}.
 \tag{5.3}
\]

On the sparse class, (3.8) or (3.9) bounds the inverse factor by $H_{k,\beta}$.
The forced open part has exactly the ordinary $\mu_{\mathbf a}$-plus-uniform-root law;
success only restricts it. Integrating (5.3), and using $1-2^{-K}\le K$, gives

\[
\begin{split}
0\le Q_d(a,r)-\nu_{a;r}(\Omega)
&\le\frac{2d}{r}\int_{\rm sparse}m_{\rm new}\,d\mu_{a,r}+D_{a,r}\\
&\le\frac{2dH_{k,\beta}}{r-2d}\mathbb E J+D_{a,r}.
\end{split}
\tag{5.4}
\]

Take $r\ge4d$ and $n=r-d$. Combining (4.3), (5.4), and
$\nu_{\mathbf a;r}(\Omega)\le Q_d(\mathbf a)$, yields the key finite recurrence

\[
\boxed{
Q_d(a,r)\le Q_d(a)
+\frac{2dH_{k,\beta}}{r-2d}
 \left[
 \frac1N\sum_{h=1}^{n-1}(n-h)Q_d(a,h)
 +\frac{2nP}{N}Q_d(a)
 \right]+D_{a,r}.
}
\tag{5.5}
\]

$D=0$ for total length below $d^4$; otherwise it is bounded by (3.6).

No long cycle is charged at a shorter cycle'$s$ rate. Prior cycles remain under
their ordinary finite measure, rather than being incorrectly treated as an
unbiased probability law after earlier forced closures.

## 6. Close the upper induction

### 6.1 Base: all lengths below $4d$

Let $B$ mean that every prescribed cyclic word is primitive and no two words
represent the same necklace. $A_d$ implies $B$. On $B$ with no repeated contexts,
the weighted integrand is exactly one.

For two distinct positions, Appendix A proves the fully wrapped-window bound
\[
 \mathbb P\{B\text{ and their }(d-1)\text{-contexts agree}\}
 \le 2^{-(d-1)}.
\]
This includes component words shorter than the window and equal component
lengths; the event $B$ removes the periodic degeneracies.

A union bound, together with $m\le L\log_2L/(2d)$, implies

\[
 Q_d(\mathbf r)\le1+\frac{L^{2k+2}}N,
 \qquad \max_i r_i<4d,\quad L<4kd.
 \tag{6.1}
\]

### 6.2 Crude bound

Induct first on the number of cycles $k$, then strongly on total length $L$ for
fixed $k$. The target crude bound is $Q_d(\mathbf r)\le 2^k$. The base (6.1) holds for large $d$.
When $r=\max_i r_i\ge4d$, all same-$k$ moments in (5.5) have total length $P+h<L$.
The lower-order moment is bounded by $2^{k-1}$. Therefore

\[
 Q_d(a,r)\le2^{k-1}
 +C_k dH_{k,\beta}(d)\frac LN+D_{a,r}.
\]

The extra terms tend to zero uniformly for $L\le N^\beta$, since $H$ is polynomial
and $\beta<1$. Thus they fit within the fixed gap from $2^{k-1}$ to $2^k$.
This closes the induction, including moment lists that contain very short
components. In particular, $Q_d(h)\le2$ for all $h\le N^\beta$.

This is a strong induction on an integer total length, within an outer
induction on the fixed order. For a fixed target order $k$, take $d$ large
enough for all orders at most $k$. At each non-base step the strictly
smaller-order term is bounded by $2^{k-1}$, while the same-order terms have
strictly smaller total. Thus there is a fixed gap available for the uniformly
vanishing error; no unproved sharp estimate is used to initialize the
recurrence.

### 6.3 Sharp constant

Substitute the crude bounds back into (5.5):

\[
 Q_d(a,r)\le Q_d(a)+C_{k,\beta}dH_{k,\beta}(d)\frac LN+D_{a,r}.
\]

Repeatedly remove a longest component. There are at most $k$ steps. The base
(6.1) costs at most a polynomial times $1/N$, absorbed by $P_{k,\beta}(d)L/N$.
For $L\ge d^4$ the dense error is at most $C_\beta2^{-d^3}$, also absorbed.
This proves (1.1).

## 7. A matching lower bound from several middle-first bridges

Only the one-cycle bound $Q_d(h)\le2$ is needed in this section.

For an ordinary trajectory of $n\ge d$ steps from a uniform root, let $R_{n,d}$
mean that some query in its final $d$ steps repeats an earlier context. The
stopped conjugate-switch identity and a union bound over time separations give

\[
 \mathbb P(R_{n,d})\le\frac{d+1}{N}\sum_{h\le n}Q_d(h)
 \le\frac{2(d+1)n}{N}.
 \tag{7.1}
\]

The event of a prior return costs $N^{-1}\sum_{h\le n}Q_d(h)$; on survival a repeated
context is a conjugate encounter, and each separation appears at most $d$ times
in the terminal query block. Coupling the last $d$ fresh outputs to fair bits
also gives

\[
 d_{\rm TV}(\mathcal L(X_0,X_n),U_N\otimes U_N)
 \le\frac{2(d+1)n}{N}.
 \tag{7.2}
\]

Coordinate reversal conjugates the inverse Thorp permutation to the same model
with its feedback arguments reversed, so these estimates hold backwards too.

More explicitly, the one-cycle instance of (4.1a) bounds the stopped
conjugate endpoint count by $Q_d(h)$. With a uniform root, a prior return
has probability $N^{-1}\sum_{h\le n}Q_d(h)$. On survival, a pair of equal
contexts consists of distinct conjugate states. For each separation $h$,
there are at most $d$ pairs with the later query among the final $d$ queries.
This proves (7.1).

For (7.2), at each of the final $d$ steps supply a new independent fair
comparison bit. If its context is new, choose the freshly revealed feedback
value to make the actual output equal that bit. If the context is old,
continue the comparison with its independent bit. The comparison endpoint
is a uniform $d$-bit state independent of the initial root; failure of the
coupling requires terminal reuse. This constructs the comparison, rather
than conditioning a collection of outputs on the event that all are fresh.

If $R_d$ reverses all $d$ coordinates, direct calculation gives
\[
 R_dT_f^{-1}R_d=T_{f\circ R_{d-1}}.
\]
The transformed feedback table is again uniform and independent, so the
same stopped-reuse and endpoint estimates hold backwards.

### 7.1 Reference construction

Assume all $r_i\ge4d$ and put $t_i=r_i-2d$. In a common ordinary feedback environment,
choose independent uniform roots $v_i$ and run middle paths of $t_i$ steps to $z_i$.
Independently choose uniform $w_i$. Add the two unique $d$-step shift paths

\[
 z_i\longrightarrow w_i\longrightarrow v_i.
\]

Let $G$ require all middle states to be distinct, within and between paths, and
all $2kd$ added query contexts to be mutually distinct and absent from every
middle queried context. On $G$ assign the fresh feedback values to realize the
added outputs and complete all remaining values fairly. This produces $k$
disjoint cycles of the required lengths.

### 7.2 Failure bounds

Internal failure of a middle path costs at most $2t_i/N$.

For different middle paths of lengths $t_i,t_j$, conditional on any fixed $f$,
an intersection entails

\[
 v_j=T_f^{a-b}v_i,
 \qquad 0\le a\le t_i,\quad0\le b\le t_j.
\]

There are at most $t_i+t_j+1$ distinct offsets. Thus

\[
 \mathbb P(\text{middle }i\text{ meets middle }j\mid f)
 \le(t_i+t_j+1)/N.
 \tag{7.3}
\]

There is no $t_it_j/N$ loss here.

For an added path, separate contacts with its **own** middle from contacts
with **other** middles. For self-contacts and contacts with its own middle,
consider just that single ordinary middle and its independent seed $w_i$.
Until the first reused query, its forward reference extension agrees with an
ordinary extension of that middle, by deferred decisions. Formula (7.1) with
$n=t_i+d$ bounds this failure. The other extension is explored backwards
from $v_i$, and the reverse-time version of (7.1) gives the same bound.
These are marginal, unconditional estimates; they do not require the
feedback law to remain ordinary after conditioning on every other trace.

For contacts with a different middle $j$, use the reference construction
directly. Conditional on $f$, every fixed context in the added path $z_i$ to
$w_i$ is uniform: it uses a suffix of the uniform $z_i$ and a prefix of the
independent uniform $w_i$. The path $w_i$ to $v_i$ has the same property.
These contexts are independent of a specified query context in middle $j$,
since $(v_i,w_i)$ and $v_j$ are independent conditional on $f$. Equality
therefore has probability $2/N$. A union bound over at most $d t_j$ pairs
for each added path costs $2dt_j/N$. Summing all the self and other-middle
bounds costs $O_k(dL/N)$.

For the two added paths belonging to the same cycle, their possible cross
contacts depend only on $z_i$,$w_i$,$v_i$. By (7.2) this triple is within
$2(d+1)t_i/N$ of three independent uniform states. Under the independent law,
$z_iw_iv_i$ is a linear independent-bit word; each of the $d^2$ possible cross-window
matches has probability $2/N$, including overlapping windows. This again sums
to $O_k(dL/N)$.

For added paths belonging to different cycles, no endpoint approximation is
needed. Conditional on $f$, the pairs ($v_i$,$w_i$) are independent across i, $z_i$ is
uniform, and each individual added context is uniform. Thus each cross-cycle
pair of added contexts agrees with probability $2/N$. There are $O(k^2d^2)$ such
pairs, costing $O(k^2d^2/N)$, absorbed into $O_k(dL/N)$.

All estimates are unconditional union bounds; the failure events are not
assumed independent. Together,

\[
 \mathbb P_{\rm ref}(G)\ge1-C_k dL/N.
 \tag{7.4}
\]

### 7.3 Exact good-history weight

Fix the middle traces, whose queried contexts number $v_M$, and the words $w_i$.
The ordinary root-and-middle probability contains $N^{-k}2^{-v_M}$. On $G$ the
$2kd$ prescribed fresh outputs have probability $N^{-2k}$; scaling the ordinary
law by $N^k$ leaves weight $2^{-(v_M+2kd)}$. The reference chooses all $w_i$ with
probability $N^{-k}$, giving the same weight $N^{-2k}2^{-v_M}$.

The reference construction only retains feedback values queried by the
middles. Values at added contexts are assigned after choosing the bridges,
and the rest are freshly completed. It does not require an initially
sampled unused feedback value to equal a forced value; those initially
unused values have been marginalized. This distinction is part of the
weight calculation, not an assumption about their conditional distribution.

Thus the scaled ordinary cycle measure equals the reference measure on $G$,
including the same uniform completion of unused feedback values. Therefore

\[
 Q_d(\mathbf r)\ge\mathbb P_{\rm ref}(G)\ge1-C_kdL/N.
\]

This proves the lower half of (1.2). It needs neither conditional independence
of endpoints given all other traces nor a joint-collision moment theorem.

## 8. Fixed-order moments and the truncated Gaussian field

Fix $0<\alpha<2/3$ and choose $\beta$ strictly between $\alpha$ and $2/3$. Let $b=\lfloor N^\alpha\rfloor$
and $\ell=\log N$. For every fixed moment order $m$ and all sufficiently large $d$,
all lists of at most $m$ lengths bounded by b have total length $\le N^\beta$.
For lengths in [$4d$,b], Theorem (1.2) gives

\[
 \max_{1\le j\le m}\ \sup_{4d\le r_1,\ldots,r_j\le b}
 |Q_d(r_1,\ldots,r_j)-1|
 \le \varepsilon_{d,m},\qquad
 \varepsilon_{d,m}=d^{O_{m,\beta}(1)}N^{\alpha-1}.
 \tag{8.1}
\]

This is smaller than every negative power of $d$ for fixed $m$.

Let $Z_r$, $4d\le r\le b$, be independent Poisson variables of means $1/r$. Their normalized
factorial moments $Q$ are exactly one. Ordinary moments of additive cycle
statistics expand over partitions of their selected cycle occurrences into
groups that refer to the same cycle. Each block contributes one harmonic
summation. For logarithmic weights, a block of multiplicity a contributes at
most

\[
 \sum_{r\le b}(\log r)^a/r=O_a(\ell^{a+1}).
\]

Consequently the error in a fixed raw $m$-th moment of the logarithmic product
is $O_m(\varepsilon_{d,m}\ell^{2m})$. Centering and Gaussian normalization multiply
this only by further powers of $\ell$. All normalized moment errors vanish.
The same argument applies to arbitrary finite collections of count and
log-product increments. The corresponding Poisson statistics have Gaussian
limits and moment-determinate limiting distributions.

For completeness, the reference Gaussian limit itself needs no
permutation-order theorem. At positions $t_r=\log r/\ell$, a linear
combination of finitely many count and normalized log-product increments
has centered Poisson form
\[
 \frac1{\sqrt\ell}\sum_{4d\le r\le b}
        g(t_r)(Z_r-1/r),
\]
where $g$ is a bounded, piecewise continuous function. Its variance converges
to $\int_0^\alpha g(t)^2\,dt$ by harmonic Riemann sums. Its cumulant of
order $j\ge3$ is
\[
 \ell^{-j/2}\sum_{4d\le r\le b}\frac{g(t_r)^j}{r}
 =O_j(\ell^{1-j/2})=o(1).
\]
Thus its moments converge to Gaussian moments. The Gaussian law is
moment-determinate; the multivariate statement follows by the
Cramér–Wold argument. The log-product coordinate corresponds to the
weight $\sqrt3\,t$, so the common limiting Brownian motion gives
$\bigl(W(u),\sqrt3\int_0^u t\,dW(t)\bigr)$.

### Tightness, not just finite-dimensional convergence

First omit lengths below $4d$. Center by the exact Poisson-reference
harmonic sums. In the log-product coordinate use weights
$\sqrt3\log r/\ell$, so both coordinates are sums with bounded weights,
divided by $\sqrt\ell$.

Extend each truncated centered process constantly beyond $\alpha$ to the
next point of the full grid $u=j/\ell$. Interpolate on this full grid and
then restrict to $[0,\alpha]$. A grid interval containing $m\ge1$ full
mesh steps has reference Poisson intensity
$O(m)$. For either normalized coordinate its fourth centered Poisson moment
is at most
\[
 \frac{C(m^2+m)}{\ell^2}.
\]
Expansion into raw moments of orders at most four and (8.1) gives the same
bound for the actual centered coordinate, plus a uniform remainder
$R_d$ that is smaller than every power of $1/\ell$. For example, the crude
bound $R_d=O(\varepsilon_{d,4}(1+\ell)^6)$ suffices. Since $m\ge1$, absorb
this remainder into a constant multiple of $(m/\ell)^2$.

Linearly interpolate the grid values. Within a grid cell an increment is a
fraction $\theta$ of the grid increment. Its fourth moment is at most
$C\theta^4/\ell^2\le C|u-v|^2$, since $\theta=\ell|u-v|\le1$.
Across cells split an interval into its first partial cell, full grid part,
and final partial cell. The inequality
$|x+y+z|^4\le27(|x|^4+|y|^4+|z|^4)$ gives the uniform continuity bound
$C|u-v|^2$. The constant extension makes the final mesh cell a full cell
as well; no uniform estimate for an arbitrarily shortened interpolation cell
is needed. The fourth-moment tightness criterion therefore applies to the
interpolated processes.

To compare with the original step processes, let $D_j$ count all cycles in
one logarithmic grid bin. Its harmonic intensity is bounded by an absolute
constant. The upper moment theorem at orders at most four gives
$\mathbb ED_j^4\le C$, uniformly over the bins. There are $O(\ell)$ bins, so
for every $\eta>0$,
\[
 \mathbb P\{\max_jD_j>\eta\sqrt\ell\}
 \le \frac{C}{\eta^4\ell}\longrightarrow0.
\]
Within a bin, the normalized log-product oscillation is at most a fixed
multiple of $D_j/\sqrt\ell$, because $\log r/\ell\le\alpha$. The deterministic
reference centerings have oscillation $O(1/\sqrt\ell)$ there. Thus both step
processes are uniformly close in probability to the tight interpolations.

Below length $4d$, $Q_d(r)\le2$ implies expected count $O(\log d)$ and expected
log-product $O((\log d)^2)$. Both vanish at their respective normalizations.
This also handles the initial interval near $u$=0. Centering by exact harmonic
sums or by the displayed polynomial centerings differs by a uniformly negligible
quantity.

Therefore, with

\[
 K_d(u)=\sum_{r\le N^u}C_r,\qquad
 B_d(u)=\sum_{r\le N^u}C_r\log r,
\]

we obtain convergence in $D([0,\alpha],\mathbb R^2)$, with continuous limiting paths:

\[
 \left(
 \frac{K_d(u)-u\ell}{\sqrt\ell},\quad
 \frac{B_d(u)-\tfrac12u^2\ell^2}{\sqrt{\ell^3/3}}
 \right)
 \Longrightarrow
 \left(W(u),\sqrt3\int_0^u t\,dW(t)\right).
 \tag{8.2}
\]

No process-level Poisson total-variation approximation is asserted here. Fixed
orders, with superpolynomially small errors for each order, are sufficient for
this moment-and-tightness argument.

## 9. Product to LCM

For all $r,s\le b$, the all-positive-length upper theorem gives, for large $d$,

\[
 \mathbb EC_r\le2/r,\qquad
 \mathbb E[C_r(C_s-\mathbf1_{r=s})]\le2/(rs).
\]

Let $D_m=\sum_{m\mid r,\ r\le b}C_r$. The exact arithmetic identity is

\[
 B_d(\alpha)-\log\operatorname{lcm}\{r\le b:C_r>0\}
 =\sum_{m\le b}\Lambda(m)(D_m-1)_+.
\]

The preceding harmonic bounds imply

\[
 \mathbb E(D_m-1)_+
 \le\min\left\{\frac{2H_{\lfloor b/m\rfloor}}m,
 \frac{H_{\lfloor b/m\rfloor}^2}{m^2}\right\}.
\]

Split at $m=\log b$ and use $\Lambda(m)\le\log m$. The expected discrepancy is

\[
 O\big(\log b\,(\log\log b)^2\big)=o(\ell^{3/2}).
\]

The discrepancy is nondecreasing with the cutoff, so the bound is uniform
on $0\le u\le\alpha$. Markov'$s$ inequality transfers (8.2) from $B_d(u)$ to

\[
 O_d(u)=\log\operatorname{lcm}\{r\le N^u:C_r>0\}.
\]

In particular, with $b=\lfloor N^\alpha\rfloor$,

\[
 \boxed{
 \frac{\log\operatorname{lcm}\{r\le b:C_r>0\}
       -\tfrac12(\log b)^2}{\sqrt{(\log b)^3/3}}
 \Longrightarrow\mathcal N(0,1),\qquad 0<\alpha<2/3.
 }
\]

This is a truncated theorem. No estimate above uses or proves a dense-tail
bound at exponent 2/3 or beyond it, where the coefficient kappa in (3.5)
ceases to give the required saving.

## Appendix A. Equality graphs for wrapped contexts

This appendix proves the small-length collision estimate used in (6.1).
Let $B$ require primitive component words and different necklaces for any
two components of the same length.

For two positions on the same circle of length $n$, with nonzero displacement
$a$, the $h$ consecutive comparisons are edges $t\leftrightarrow t+a$ modulo
$n$. Write $g=\gcd(n,a)$. For $h<n$, the omitted $n-h$ starting positions are
consecutive and meet $\min(g,n-h)$ of the $g$ cycles of the full shift graph.
The retained equality system therefore has rank
\[
 h-\max(0,g-n+h)=\min(h,n-g)
\]
over $\mathbb F_2$. The same formula holds for $h\ge n$, when the rank has
already saturated. If $h\ge n-g$, equality forces period dividing $g<n$,
which is impossible on $B$. Otherwise the rank is $h$, so equality has
probability $2^{-h}$. This includes a two-cycle in the shift graph: its two
oriented edges impose one linear relation.

For positions on different circles of lengths $r,s$, offset their roots so
that the comparisons are
$(t\bmod r)\leftrightarrow(t\bmod s)$, $0\le t<h$, in a bipartite graph.
Let $g=\gcd(r,s)$ and assume $r\le s$. Its first $s$ edges attach each
vertex of the second circle once. Contract those edges. The next $r-g$
edges become $j\leftrightarrow j+s\pmod r$, $0\le j<r-g$. The full
shift-by-$s$ graph has $g$ cycles, and the omitted $g$ consecutive edges
remove exactly one from each. Thus the first $r+s-g$ comparison edges form
a forest and have that rank. At this threshold both words are forced to
have period dividing $g$. This is excluded by $B$: either a component is
nonprimitive, or the two have equal length and represent the same necklace.
For smaller $h$ the comparisons have rank $h$ and probability $2^{-h}$.

Taking $h=d-1$ proves, for every pair of distinct positions,
\[
 \mathbb P\{B\text{ and their contexts agree}\}\le2^{-(d-1)}.
\]
On $B$ without such a collision, the weighted-word integrand equals one.
On valid words its maximum is
$2^m\le L^{L/(2d)}\le L^{2k}$ when every length is below $4d$.
The union bound over $\binom L2$ pairs gives (6.1).

## Appendix $B$. Review and computational record

The supplied source and its audit ZIP have been preserved byte-for-byte in
the accompanying archive. The reviewed version expands the marked
switching proof, the finite-measure likelihood normalization, the
small-length base, the asymptotic parameter calculation, the two-stage
induction, the bridge contact estimates, and the functional tightness
argument. No change to the stated range or normalization was needed.

Both supplied scripts were rerun. Their JSON outputs reproduced the supplied
JSON exactly. The rerun covers 272 complete feedback environments in dimensions
3 and 4 and seeded deterministic tests in 512 environments in dimensions
5 and 6. It reports 873 aggregate marked switching bounds, 175 partial-forcing
and open-collision bounds, 243,751 root identities, 9,998 convexity checks,
53,733 entropy/mixture checks, and 262 complete short-word type classes.
The bridge rerun reproduces 384 conditional marginal checks and 852 good
histories among 13,500 seeded reference samples.

A separately implemented atom-level audit exhausts every feedback table in
dimensions 2 through 5: 65,812 environments and 1,050,696 context flips. It
checks the actual feedback-bit flip, both split lengths, both orientations,
and preservation of every spectator cycle. There were 2,299,204 spectator
cycle preservation checks. A separate equality-graph audit verifies 174,720
same-circle ranks and 97,600 different-circle ranks, including overlap,
wraparound, equal lengths, and windows longer than their component words.
All executed assertions passed.

These computations verify finite ingredients only. They do not test the
asymptotic entropy tail at exponentially long lengths. That step is established
analytically in Section 3. This review found no unresolved mathematical gap
in the stated fixed-parameter range; it is not independent peer review or
proof-assistant certification. The separate audit report contains the full
dependency assessment and reproduction instructions.

## Context and references

The model is exactly the binary noncoalescing feedback permutation studied
by Arratia, Canfield, and Hales [ACH]. Their large-cycle theorem is a
Poisson–Dirichlet limit, and their paper explicitly distinguishes that
weak limit from local cycle-length asymptotics. It is not an input to the
present proof. The short-cycle literature includes Stark [Stark]. These
references give context; a comprehensive priority or novelty review has
not been completed here.

[ACH] R. A. Arratia, E. R. Canfield, and A. W. Hales, *Random Feedback Shift
Registers, and the Limit Distribution for Largest Cycle Lengths*,
arXiv:1903.09183, version 4, 2022, especially Sections 1–2.

[Stark] D. Stark, *The small cycle counts of random feedback shift registers*,
Australasian Journal of Combinatorics **86** (2023), 414–422.
