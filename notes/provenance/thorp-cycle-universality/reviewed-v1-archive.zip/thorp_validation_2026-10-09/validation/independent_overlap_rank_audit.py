#!/usr/bin/env python3
"""Exact rank tests for the equality graphs in the small-length base.
A graph equality system over F_2 has rank vertices minus components.
These finite tests supplement the general forest proof, not replace it.
"""
import json, math
from pathlib import Path
class DSU:
    def __init__(self,n): self.parent=list(range(n)); self.rank=0
    def find(self,x):
        while self.parent[x]!=x:
            self.parent[x]=self.parent[self.parent[x]]; x=self.parent[x]
        return x
    def edge(self,x,y):
        x,y=self.find(x),self.find(y)
        if x!=y: self.parent[x]=y; self.rank+=1
same=cross=0
for n in range(2,65):
    for a in range(1,n):
        g=math.gcd(n,a); dsu=DSU(n)
        for h in range(1,2*n+1):
            dsu.edge((h-1)%n,(h-1+a)%n)
            assert dsu.rank==min(h,n-g),(n,a,h,dsu.rank)
            same+=1
for r in range(1,41):
    for s in range(1,41):
        g=math.gcd(r,s); dsu=DSU(r+s)
        for h in range(1,r+s+21):
            dsu.edge((h-1)%r,r+(h-1)%s)
            assert dsu.rank==min(h,r+s-g),(r,s,h,dsu.rank)
            cross+=1
out={'status':'all assertions passed','same_circle_rank_cases':same,
     'different_circle_rank_cases':cross,
     'scope':'Exact ranks, including overlaps, wraparound, equal lengths, and periods shorter than the window.'}
print(json.dumps(out,indent=2))
