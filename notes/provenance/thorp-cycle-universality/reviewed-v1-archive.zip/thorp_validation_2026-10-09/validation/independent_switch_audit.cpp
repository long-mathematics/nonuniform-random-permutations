// Exhaustive atom-level feedback-flip audit. No asymptotic conclusion is inferred.
// Build: g++ -O2 -std=c++17 independent_switch_audit.cpp -o independent_switch_audit
#include <algorithm>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <vector>
using U=std::uint64_t;
struct Decomp { std::vector<int> cid,pos,len; std::vector<U> masks; };
Decomp split(const std::vector<int>& p){
 const int n=p.size(); Decomp a; a.cid.assign(n,-1); a.pos.resize(n); a.len.resize(n);
 for(int x=0;x<n;++x) if(a.cid[x]<0){
  int id=a.masks.size(), y=x; std::vector<int> c; U mask=0;
  do { if(a.cid[y]>=0){std::cerr<<"not a permutation cycle\n";std::exit(1);} a.cid[y]=id; a.pos[y]=c.size(); c.push_back(y); mask|=U(1)<<y; y=p[y]; }while(y!=x);
  for(int z:c) a.len[z]=c.size(); a.masks.push_back(mask);
 } return a;
}
void require(bool b){ if(!b){std::cerr<<"ASSERTION FAILED\n";std::exit(1);} }
int main(){
 U environments=0, flips=0, split_atoms=0, join_atoms=0, spectators=0;
 for(int d=2;d<=5;++d){int n=1<<d,half=n/2; U nf=U(1)<<half;
  for(U f=0;f<nf;++f){std::vector<int> p(n); for(int x=0;x<n;++x) p[x]=((x&(half-1))<<1)|((x>>(d-1))^int((f>>(x&(half-1)))&1)); auto a=split(p); ++environments;
   for(int u=0;u<half;++u){int x=u,y=u+half; auto q=p; std::swap(q[x],q[y]); auto b=split(q); ++flips;
    for(int z=0;z<n;++z){int expected=((z&(half-1))<<1)|((z>>(d-1))^int(((f^(U(1)<<u))>>(z&(half-1)))&1)); require(q[z]==expected);}
    if(a.cid[x]==a.cid[y]){
      int h=(a.pos[y]-a.pos[x]+a.len[x])%a.len[x]; require(h>0&&h<a.len[x]);
      require(b.cid[x]!=b.cid[y]&&b.len[y]==h&&b.len[x]==a.len[x]-h);
      require((b.masks[b.cid[x]]|b.masks[b.cid[y]])==a.masks[a.cid[x]]);
      split_atoms+=2;
      for(std::size_t j=0;j<a.masks.size();++j)if(int(j)!=a.cid[x]){require(std::find(b.masks.begin(),b.masks.end(),a.masks[j])!=b.masks.end());++spectators;}
    }else{
      require(b.cid[x]==b.cid[y]&&b.len[x]==a.len[x]+a.len[y]);
      int h=(b.pos[y]-b.pos[x]+b.len[x])%b.len[x]; require(h==a.len[y]);
      require(b.masks[b.cid[x]]==(a.masks[a.cid[x]]|a.masks[a.cid[y]]));
      join_atoms+=2;
      for(std::size_t j=0;j<a.masks.size();++j)if(int(j)!=a.cid[x]&&int(j)!=a.cid[y]){require(std::find(b.masks.begin(),b.masks.end(),a.masks[j])!=b.masks.end());++spectators;}
    }
   }
  }
 }
 std::cout<<"{\n  \"status\": \"all assertions passed\",\n  \"dimensions\": [2,3,4,5],\n  \"exhaustive_feedback_environments\": "<<environments<<",\n  \"context_flips\": "<<flips<<",\n  \"oriented_split_atoms\": "<<split_atoms<<",\n  \"oriented_join_atoms\": "<<join_atoms<<",\n  \"unchanged_spectator_cycles\": "<<spectators<<",\n  \"scope\": \"Exact split/join lengths, actual feedback flip, and preservation of all spectator cycles; not an asymptotic test.\"\n}\n";
}
