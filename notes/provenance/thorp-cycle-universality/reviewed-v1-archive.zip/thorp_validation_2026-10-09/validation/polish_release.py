from pathlib import Path
p=Path(__file__).resolve().parents[1]/'release/thorp_alpha_lt_two_thirds.md'
s=p.read_text()
repl={
'For all sufficiently large d, depending on k and beta:':'For all sufficiently large $d$, depending on $k$ and $\\beta$:',
'for all positive r_i with L<=N^beta,':'for all positive $r_i$ with $L\\le N^\\beta$,',
'if also every r_i>=4d, then':'if also every $r_i\\ge4d$, then',
'uniformly for r,s>=4d and r+s<=N^beta.':'uniformly for $r,s\\ge4d$ and $r+s\\le N^\\beta$.',
'h-block distribution and delta_h=H_h-H_{h-1}. A fixed h-type contains at most':'$h$-block distribution and $\\delta_h=H_h-H_{h-1}$. A fixed $h$-type contains at most',
'rooted words. For h<=n, use the empirical order-(h-1) Markov chain:':'rooted words. For $h\\le n$, use the empirical order-$(h-1)$ Markov chain:',
'Also delta_h=0 once h-1>=n.':'Also $\\delta_h=0$ once $h-1\\ge n$.',
'For h>n,':'For $h>n$,',
'for h>n,':'for $h>n$,',
'Suppose d^4<=L<=N^beta, and put q=log_2 d and':'Suppose $d^4\\le L\\le N^\\beta$, and put $q=\\log_2d$ and',
'For sufficiently large d, h>=2, h<=beta d,':'For sufficiently large $d$, $h\\ge2$ and $h\\le\\beta d$,',
'When r=max r_i, L/r<=k.':'When $r=\\max_i r_i$, $L/r\\le k$.',
'For L<d^4 no dense decomposition is necessary.':'For $L<d^4$ no dense decomposition is necessary.',
'so, for any m_new<=m,':'so, for any $m_{\\rm new}\\le m$,',
'Let a=(r_1,...,r_{k-1}), P=sum a_i, and let mu_a be its scaled ordinary cycle':'Let $\\mathbf a=(r_1,\\ldots,r_{k-1})$, $P=\\sum_i a_i$, and let $\\mu_{\\mathbf a}$ be its scaled ordinary cycle',
'Q_d(a,h). Stationarity':'$Q_d(\\mathbf a,h)$. Stationarity',
'about f under mu_a.':'about $f$ under $\\mu_{\\mathbf a}$.',
'Sort r_1<=...<=r_k=r. Keep the earlier cycles under mu_a.':'Sort $r_1\\le\\cdots\\le r_k=r$. Keep the earlier cycles under $\\mu_{\\mathbf a}$.',
'by nu_{a;r}. Its mass is at most Q_d(a),':'by $\\nu_{\\mathbf a;r}$. Its mass is at most $Q_d(\\mathbf a)$,',
'The function j -> j 2^{j-m_new} is increasing and convex for j>=0.':'The function $j\\mapsto j2^{j-m_{\\rm new}}$ is increasing and convex for $j\\ge0$.',
'by H_{k,beta}.':'by $H_{k,\\beta}$.',
'ordinary mu_a-plus-uniform-root law;':'ordinary $\\mu_{\\mathbf a}$-plus-uniform-root law;',
'using 1-2^{-K}<=K,':'using $1-2^{-K}\\le K$,',
'Take r>=4d and n=r-d.':'Take $r\\ge4d$ and $n=r-d$.',
'nu_{a;r}(Omega)<=Q_d(a),':'$\\nu_{\\mathbf a;r}(\\Omega)\\le Q_d(\\mathbf a)$,',
'D=0 for total length below d^4;':'$D=0$ for total length below $d^4$;',
'together with m<=L log_2 L/(2d),':'together with $m\\le L\\log_2L/(2d)$,',
'When r=max r_i>=4d, all same-k moments in (5.5) have total length P+h<L.':'When $r=\\max_i r_i\\ge4d$, all same-$k$ moments in (5.5) have total length $P+h<L$.',
'for L<=N^beta,':'for $L\\le N^\\beta$,',
'In particular, Q_d(h)<=2 for all h<=N^beta.':'In particular, $Q_d(h)\\le2$ for all $h\\le N^\\beta$.',
'For L>=d^4 the dense error is at most C_beta 2^{-d^3},':'For $L\\ge d^4$ the dense error is at most $C_\\beta2^{-d^3}$,',
'Only the one-cycle bound Q_d(h)<=2 is needed in this section.':'Only the one-cycle bound $Q_d(h)\\le2$ is needed in this section.',
'For an ordinary trajectory of n>=d steps from a uniform root, let R_{n,d}':'For an ordinary trajectory of $n\\ge d$ steps from a uniform root, let $R_{n,d}$',
'(sum_{h<=n}Q_d(h))/N;':'$N^{-1}\\sum_{h\\le n}Q_d(h)$;',
'Assume all r_i>=4d and put t_i=r_i-2d.':'Assume all $r_i\\ge4d$ and put $t_i=r_i-2d$.',
'z_i w_i v_i is a linear iid binary word; each of the d^2 possible cross-window':'$z_iw_iv_i$ is a linear independent-bit word; each of the $d^2$ possible cross-window',
'of z_i,w_i,v_i.':'of $(z_i,w_i,v_i)$.',
'2(d+1)t_i/N of three independent uniform states.':'$2(d+1)t_i/N$ of three independent uniform states.',
'pair of added contexts agrees with probability 2/N. There are O(k^2d^2) such':'pair of added contexts agrees with probability $2/N$. There are $O(k^2d^2)$ such',
'pairs, costing O(k^2d^2/N), absorbed into O_k(dL/N).':'pairs, costing $O(k^2d^2/N)$, absorbed into $O_k(dL/N)$.',
'contains N^{-k}2^{-v_M}.':'contains $N^{-k}2^{-v_M}$.',
'probability N^{-2k}; scaling the ordinary':'probability $N^{-2k}$; scaling the ordinary',
'law by N^k leaves weight 2^{-(v_M+2kd)}.':'law by $N^k$ leaves weight $2^{-(v_M+2kd)}$.',
'probability N^{-k}, giving the same weight N^{-2k}2^{-v_M}.':'probability $N^{-k}$, giving the same weight $N^{-2k}2^{-v_M}$.',
'Fix 0<alpha<2/3 and choose beta strictly between alpha and 2/3. Let b=floor(N^alpha)\nand ell=log N.':'Fix $0<\\alpha<2/3$ and choose $\\beta$ strictly between $\\alpha$ and $2/3$. Let $b=\\lfloor N^\\alpha\\rfloor$\nand $\\ell=\\log N$.',
'total length <=N^beta.':'total length $\\le N^\\beta$.',
'Let Z_r, 4d<=r<=b, be independent Poisson variables of means 1/r.':'Let $Z_r$, $4d\\le r\\le b$, be independent Poisson variables of means $1/r$.',
'Below length 4d, Q_d(r)<=2 implies expected count O(log d) and expected\nlog-product O((log d)^2).':'Below length $4d$, $Q_d(r)\\le2$ implies expected count $O(\\log d)$ and expected\nlog-product $O((\\log d)^2)$.',
'For all r,s<=b,':'For all $r,s\\le b$,',
'Let D_m=sum_{m|r,r<=b} C_r.':'Let $D_m=\\sum_{m\\mid r,\\ r\\le b}C_r$.',
'Split at m=log b and use Lambda(m)<=log m.':'Split at $m=\\log b$ and use $\\Lambda(m)\\le\\log m$.',
'on 0<=u<=alpha.':'on $0\\le u\\le\\alpha$.',
'from B_d(u) to':'from $B_d(u)$ to',
'with b=floor(N^alpha),':'with $b=\\lfloor N^\\alpha\\rfloor$,',
'For a valid family, sample a position uniformly among its L positions':'For a valid family, sample a position uniformly among its $L$ positions',
'Cramer–Wold':'Cramér–Wold',
}
for a,b in repl.items():s=s.replace(a,b)
s=s.replace('Take a grid of mesh $1/\\ell$ in $u$, including the right endpoint. A grid\ninterval containing $m\\ge1$ full mesh steps has reference Poisson intensity',
'''Extend each truncated centered process constantly beyond $\\alpha$ to the
next point of the full grid $u=j/\\ell$. Interpolate on this full grid and
then restrict to $[0,\\alpha]$. A grid interval containing $m\\ge1$ full
mesh steps has reference Poisson intensity''')
s=s.replace('''$C|u-v|^2$. The same argument handles the final shorter cell by extending
the process constantly to the next mesh point before restricting back to
$[0,\\alpha]$. The fourth-moment tightness criterion therefore applies to
the interpolated processes.''','''$C|u-v|^2$. The constant extension makes the final mesh cell a full cell
as well; no uniform estimate for an arbitrarily shortened interpolation cell
is needed. The fourth-moment tightness criterion therefore applies to the
interpolated processes.''')
p.write_text(s)
# Normalize remaining mathematical shorthand inherited from the working note.
# Never modify an existing inline/display math span.
import re
s=p.read_text()
expr={
'r_i/r_j':r'r_i/r_j', 'E_r':r'E_{\mathbf r}', 'A_d':r'A_d',
'H_h':r'H_h', '2^{-v}':r'2^{-v}', 'n^{-1}2^{-n delta_h}':r'n^{-1}2^{-n\delta_h}',
'M=2^h':r'M=2^h', 'L^k':r'L^k', 'J_int':r'J_{\rm int}', 'J_cross':r'J_{\rm cross}',
'L_f(y)>h':r'L_f(y)>h', 'T_f':r'T_f', 'm_new':r'm_{\rm new}',
'2^{k-1}':r'2^{k-1}', '2^k':r'2^k', 'beta<1':r'\beta<1',
'P_{k,beta} L/N':r'P_{k,\beta}(d)L/N', 'v_i':r'v_i','w_i':r'w_i','z_i':r'z_i',
't_i+t_j+1':r't_i+t_j+1', 't_i t_j/N':r't_it_j/N', '2t_i/N':r'2t_i/N',
't_i,t_j':r't_i,t_j', 't_i':r't_i', 'O_k(dL/N)':r'O_k(dL/N)',
'v_M':r'v_M', 'O_m(epsilon_{d,m} ell^{2m})':r'O_m(\varepsilon_{d,m}\ell^{2m})',
'D([0,alpha],R^2)':r'D([0,\alpha],\mathbb R^2)', '2/N':r'2/N', '1/r':r'1/r',
'1/n':r'1/n', '1/N':r'1/N', 'L<4kd':r'L<4kd', '4d':r'4d',
'm=L-v':r'm=L-v', 'h>0':r'h>0', 'h>n':r'h>n', 'n+1':r'n+1',
'r-d':r'r-d', '2kd':r'2kd', '2kd':r'2kd', 'O(log d)':r'O(\log d)',
'O((log d)^2)':r'O((\log d)^2)', 'f under':r'f\text{ under}',
}
# Do not replace ordinary phrases with a math \text command.
expr.pop('f under')
pat=re.compile('|'.join(re.escape(x) for x in sorted(expr,key=len,reverse=True)))
mathsplit=re.compile(r'(\\\[.*?\\\]|\\\(.*?\\\)|\$[^$]*\$)',re.S)
parts=mathsplit.split(s)
for i in range(0,len(parts),2):
 parts[i]=pat.sub(lambda m:'$'+expr[m.group(0)]+'$',parts[i])
s=''.join(parts)
# A second pass puts standalone variable names/Greek parameter names in math.
parts=mathsplit.split(s)
varpat=re.compile(r'(?<![\\\w])(?:alpha|beta|ell|delta_h|[dfhklmnpqrstuvwxyzLNPQXYZJKHBG])(?![\w])')
for i in range(0,len(parts),2):
 def fmt(m):
  w=m.group(0); return '$'+({'alpha':r'\alpha','beta':r'\beta','ell':r'\ell','delta_h':r'\delta_h'}.get(w,w))+'$'
 parts[i]=varpat.sub(fmt,parts[i])
s=''.join(parts)
s=s.replace(r'{n+M-1\choose M-1}',r'\binom{n+M-1}{M-1}')
p.write_text(s)
