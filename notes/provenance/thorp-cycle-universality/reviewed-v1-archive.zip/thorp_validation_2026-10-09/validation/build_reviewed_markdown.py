#!/usr/bin/env python3
"""Create reviewed source without modifying the supplied source snapshot."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
s=(root/'original/thorp_multiscale_cycle_moments.md').read_text()
start=s.index('## 1. Statement')
s=s[start:]
header=r'''---
title: "Mesoscopic cycle universality for a single Thorp shuffle"
subtitle: "Uniform multicycle moments and the truncated functional Erdős–Turán law"
author: "Christopher D. Long"
date: "9 October 2026 — reviewed proof, version 1.0"
fontsize: 11pt
geometry: margin=1in
colorlinks: false
---

## Abstract and scope

For a uniformly chosen binary noncoalescing feedback shift register of width
$d$, we prove uniform joint cycle factorial-moment estimates for every fixed
number of cycles whose total length is at most $N^\beta$, where $N=2^d$ and
$\beta<2/3$. The estimates are independent of the ratios of the prescribed
lengths. They imply the joint functional Gaussian limit for cycle counts and
logarithmic truncated permutation order on every fixed interval
$[0,\alpha]$, $\alpha<2/3$.

The proof uses an exact weighted-word identity, a finite-measure version of
longest-last forced closure, a stopped marked switching inequality, cyclic
empirical-type entropy bounds, and a multicycle middle-first bridge. The
feedback function is sampled once and reused. No independent-round mixing
result, protected-cut lemma, or Poisson–Dirichlet limit is used in the proof.

This is a reviewed research proof, not a claim of formal verification or
independent peer review. The accompanying audit report records the review,
reproduced tests, new tests, changes from the supplied manuscript, and limits
of the verification. The result is truncated: the endpoint $2/3$, the full
permutation-order conjecture, growing-order factorial moments, and a
growing-dimensional Poisson total-variation approximation beyond the birthday
range are not asserted.

Throughout,
\[
 N=2^d,\qquad
 T_f(x_1,\ldots,x_d)
 =(x_2,\ldots,x_d,x_1\oplus f(x_2,\ldots,x_d)),
\]
where the $N/2$ feedback values are independent fair bits. Write $C_r$ for the
number of $r$-cycles, $u(x)$ for the last $d-1$ bits of a state, and $\bar x$
for the state obtained by flipping its first bit. Entropies and $\log_2$ are
in bits; logarithms in order statistics are natural. The notation $(z)_a$
means a falling factorial, and the LCM of an empty set is one.

'''
s=header+s
s=s.replace('has total mass Q_d(r).','has total mass $Q_d(\\mathbf r)$.')
s=s.replace('The target crude bound is Q_d(r)<=2^k.','The target crude bound is $Q_d(\\mathbf r)\\le 2^k$.')
s=s.replace('Fix k and 0<beta<2/3. Set', r'Fix an integer $k\ge1$ and a real $0<\beta<2/3$. Set')
# Add the functional statement up front.
needle='## 2. Exact cycle measures and weighted words'
insert=r'''### Functional consequence

Fix $0<\alpha<2/3$, put $\ell=\log N$, and define, for $0\le u\le\alpha$,
\[
 K_d(u)=\sum_{r\le\lfloor N^u\rfloor}C_r,
 \qquad
 O_d(u)=\log\operatorname{lcm}\{r\le\lfloor N^u\rfloor:C_r>0\}.
\]
Then, in $D([0,\alpha],\mathbb R^2)$ with its Skorokhod $J_1$ topology,
\[
 \left(
 \frac{K_d(u)-u\ell}{\sqrt\ell},
 \frac{O_d(u)-\tfrac12u^2\ell^2}{\sqrt{\ell^3/3}}
 \right)_{0\le u\le\alpha}
 \ \Longrightarrow\
 \left(W(u),\sqrt3\int_0^u t\,dW(t)\right)_{0\le u\le\alpha}.
 \tag{1.3}
\]
Here $W$ is one standard Brownian motion, shared by both coordinates. In
particular, for $b=\lfloor N^\alpha\rfloor$,
\[
 \frac{\log\operatorname{lcm}\{r\le b:C_r>0\}
       -\tfrac12(\log b)^2}{\sqrt{(\log b)^3/3}}
 \ \Longrightarrow\ \mathcal N(0,1).
 \tag{1.4}
\]
The proof of the functional consequence, including tightness, is given in
Sections 8–9. The parameters $k,\beta,\alpha$ are fixed before $d\to\infty$;
no uniform assertion as $k\to\infty$ or $\beta\uparrow2/3$ is made.

'''
assert needle in s;s=s.replace(needle,insert+needle)
# Explain stars-and-bars inequality and explicit sparse parameter algebra.
needle='### 3.2 Mixture entropy'
insert=r'''Indeed, the nonnegative block counts sum to $n$. Stars and bars gives the
first bound in (3.2); then
$\binom{n+M-1}{M-1}\le\binom{n+M}{M}\le[e(n+M)/M]^M$.
No assumption that different component types are independent is used.

'''
s=s.replace(needle,insert+needle)
needle='When r=max r_i, L/r<=k. Hence the closing penalty at the longest cycle\'s scale'
insert=r'''For clarity, the algebra behind (3.7) is
\[
 \frac{2dm_0}{L}
 \le \frac{2d}{2d-3h}
 \left[t+(2k+1)\frac hd+\frac{kh\log_2L}{L}\right]
 +\frac{2d}{L}.
\]
The leading multiplier is at most $p_\beta$;
$t\in[\log_2d+\log_2\log_2d,\,
\log_2d+\log_2\log_2d+1)$, $h/d\le\beta$, and
$h\log_2L/L=O_\beta(d^{-2})$ because $L\ge d^4$.
Also, summation in (3.6) uses the finite positive lower bound on $\kappa$:
$\sum_{m\ge m_0}2^{F-\kappa m}\le
2^{-L/d}/(1-2^{-\kappa})$.

'''
assert needle in s;s=s.replace(needle,insert+needle)
# Explicit marked switch with all prior cycles retained.
needle='### 4.2 Cross contacts'
insert=r'''Here is the normalization and bijection in (4.1). Write
$\mathcal C_f(y)$ for the cycle containing $y$ and $A$ for the union of the
previously marked cycles. Feedback-bit switching gives
\[
 \int\!\mu_{\mathbf a}(d(f,\text{marks}))
 \sum_{\substack{y:T_f^hy=\bar y,\ L_f(y)>h\\
                  \mathcal C_f(y)\cap A=\varnothing}}1
 \le Q_d(\mathbf a,h).
 \tag{4.1a}
\]
To see this, flip the bit at $u(y)$. In the new permutation the cycle containing
$\bar y$ has length $h$, and $y$ is outside it. All earlier marked cycles,
including their roots, are unchanged. The map is injective: from the new
marked $h$-cycle rooted at $\bar y$, recover $y$, flip the same bit, and
recover the original configuration. Counting all marked $h$-cycles can only
enlarge the image. The uniform feedback law is invariant under this flip.
The factor $h$ in $Q_d(\mathbf a,h)$ counts its possible new roots, including
when $h$ equals one of the earlier lengths.

For a retained prefix and query times $i<j$, take $y=T_f^iX$ and $h=j-i$.
Conditional on $f$ and the earlier marks, $y$ is uniform. The retained prefix
is in a cycle disjoint from $A$; disjointness of a prefix from $A$ implies this
because $A$ is a union of complete cycles. It also has $L_f(y)>n>h$.
Dropping the stronger retention conditions and applying (4.1a) gives
$Q_d(\mathbf a,h)/N$ for each pair. There are $n-h$ query pairs with separation
$h$, proving (4.1). No unconditioned stationarity assertion is substituted
for this marked calculation.

'''
s=s.replace(needle,insert+needle)
needle='Consequently the ordinary open-repeat statistic J satisfies'
insert=r'''On a retained prefix, each context occurs at most twice across its query
states and the earlier cycles: a context has only two preceding states, and
all these states are distinct. Hence a prefix query cannot simultaneously
repeat an earlier prefix query and a context in the marked cycles. Thus the
reused-query count is exactly $J=J_{\rm int}+J_{\rm cross}$ on retained
histories. Both quantities are set to zero on discarded histories; only the
cross bound is enlarged by dropping retention.

'''
s=s.replace(needle,insert+needle)
needle='Denote this finite successful measure by nu_{a;r}. Its mass is at most Q_d(a),'
insert=r'''Operationally, first sample the *recorded* marked-cycle histories from the
projection of $\mu_{\mathbf a}$, which is a finite measure. Sample only the
still-unqueried feedback values as the new trajectory needs them, and
complete the remaining values at the end. This avoids treating the biased
law after an earlier forced closure as an ordinary feedback law. Every
previously selected cycle constrains only its own queried contexts.

'''
s=s.replace(needle,insert+needle)
needle='where K counts closing queries already known either from earlier cycles or'
insert=r'''For an atom with $v_{\rm old}$ old contexts and $v$ contexts in the completed
family, the scaled ordinary word weight is $2^{-v}$. The forced construction
samples the new root with factor $N^{-1}$ and samples only
$v-v_{\rm old}-(d-K)$ additional feedback bits fairly. Its weight is therefore
$2^{-v_{\rm old}}N^{-1}
2^{-[v-v_{\rm old}-(d-K)]}=2^{-v-K}$.
Unused fair completion is identical. This proves (5.1) at the atom level.

'''
s=s.replace(needle,insert+needle)
# Replace terse base rank explanation with reference to full appendix.
a=s.index('For two distinct positions,',s.index('### 6.1 Base:'))
b=s.index('A union bound, together with',a)
s=s[:a]+r'''For two distinct positions, Appendix A proves the fully wrapped-window bound
\[
 \mathbb P\{B\text{ and their }(d-1)\text{-contexts agree}\}
 \le 2^{-(d-1)}.
\]
This includes component words shorter than the window and equal component
lengths; the event $B$ removes the periodic degeneracies.

'''+s[b:]
needle='### 6.3 Sharp constant'
insert=r'''This is a strong induction on an integer total length, within an outer
induction on the fixed order. For a fixed target order $k$, take $d$ large
enough for all orders at most $k$. At each non-base step the strictly
smaller-order term is bounded by $2^{k-1}$, while the same-order terms have
strictly smaller total. Thus there is a fixed gap available for the uniformly
vanishing error; no unproved sharp estimate is used to initialize the
recurrence.

'''
s=s.replace(needle,insert+needle)
needle='### 7.1 Reference construction'
insert=r'''More explicitly, the one-cycle instance of (4.1a) bounds the stopped
conjugate endpoint count by $Q_d(h)$. With a uniform root, a prior return
has probability $N^{-1}\sum_{h\le n}Q_d(h)$. On survival, a pair of equal
contexts consists of distinct conjugate states. For each separation $h$,
there are at most $d$ pairs with the later query among the final $d$ queries.
This proves (7.1).

For (7.2), at each of the final $d$ steps supply a new independent fair
comparison bit. If its context is new, choose the freshly revealed feedback
value to make the actual output equal that bit. If the context is old,
continue the comparison with its independent bit. The comparison endpoint
is a uniform $d$-bit state independent of the initial root; failure of the
coupling requires terminal reuse. This constructs the comparison, rather
than conditioning a collection of outputs on the event that all are fresh.

If $R_d$ reverses all $d$ coordinates, direct calculation gives
\[
 R_dT_f^{-1}R_d=T_{f\circ R_{d-1}}.
\]
The transformed feedback table is again uniform and independent, so the
same stopped-reuse and endpoint estimates hold backwards.

'''
s=s.replace(needle,insert+needle)
# Replace delicate boundary probability paragraph.
a=s.index('For each forward added path, couple until its first query')
b=s.index('For the two added paths belonging to the same cycle,',a)
s=s[:a]+r'''For an added path, separate contacts with its **own** middle from contacts
with **other** middles. For self-contacts and contacts with its own middle,
consider just that single ordinary middle and its independent seed $w_i$.
Until the first reused query, its forward reference extension agrees with an
ordinary extension of that middle, by deferred decisions. Formula (7.1) with
$n=t_i+d$ bounds this failure. The other extension is explored backwards
from $v_i$, and the reverse-time version of (7.1) gives the same bound.
These are marginal, unconditional estimates; they do not require the
feedback law to remain ordinary after conditioning on every other trace.

For contacts with a different middle $j$, use the reference construction
directly. Conditional on $f$, every fixed context in the added path $z_i$ to
$w_i$ is uniform: it uses a suffix of the uniform $z_i$ and a prefix of the
independent uniform $w_i$. The path $w_i$ to $v_i$ has the same property.
These contexts are independent of a specified query context in middle $j$,
since $(v_i,w_i)$ and $v_j$ are independent conditional on $f$. Equality
therefore has probability $2/N$. A union bound over at most $d t_j$ pairs
for each added path costs $2dt_j/N$. Summing all the self and other-middle
bounds costs $O_k(dL/N)$.

'''+s[b:]
needle='Thus the scaled ordinary cycle measure equals the reference measure on G,'
insert=r'''The reference construction only retains feedback values queried by the
middles. Values at added contexts are assigned after choosing the bridges,
and the rest are freshly completed. It does not require an initially
sampled unused feedback value to equal a forced value; those initially
unused values have been marginalized. This distinction is part of the
weight calculation, not an assumption about their conditional distribution.

'''
s=s.replace(needle,insert+needle)
# Expand full probability limit section.
a=s.index('### Tightness, rather than just finite-dimensional convergence')
b=s.index('Below length 4d,',a)
s=s[:a]+r'''For completeness, the reference Gaussian limit itself needs no
permutation-order theorem. At positions $t_r=\log r/\ell$, a linear
combination of finitely many count and normalized log-product increments
has centered Poisson form
\[
 \frac1{\sqrt\ell}\sum_{4d\le r\le b}
        g(t_r)(Z_r-1/r),
\]
where $g$ is a bounded, piecewise continuous function. Its variance converges
to $\int_0^\alpha g(t)^2\,dt$ by harmonic Riemann sums. Its cumulant of
order $j\ge3$ is
\[
 \ell^{-j/2}\sum_{4d\le r\le b}\frac{g(t_r)^j}{r}
 =O_j(\ell^{1-j/2})=o(1).
\]
Thus its moments converge to Gaussian moments. The Gaussian law is
moment-determinate; the multivariate statement follows by the
Cramer–Wold argument. The log-product coordinate corresponds to the
weight $\sqrt3\,t$, so the common limiting Brownian motion gives
$\bigl(W(u),\sqrt3\int_0^u t\,dW(t)\bigr)$.

### Tightness, not just finite-dimensional convergence

First omit lengths below $4d$. Center by the exact Poisson-reference
harmonic sums. In the log-product coordinate use weights
$\sqrt3\log r/\ell$, so both coordinates are sums with bounded weights,
divided by $\sqrt\ell$.

Take a grid of mesh $1/\ell$ in $u$, including the right endpoint. A grid
interval containing $m\ge1$ full mesh steps has reference Poisson intensity
$O(m)$. For either normalized coordinate its fourth centered Poisson moment
is at most
\[
 \frac{C(m^2+m)}{\ell^2}.
\]
Expansion into raw moments of orders at most four and (8.1) gives the same
bound for the actual centered coordinate, plus a uniform remainder
$R_d$ that is smaller than every power of $1/\ell$. For example, the crude
bound $R_d=O(\varepsilon_{d,4}(1+\ell)^6)$ suffices. Since $m\ge1$, absorb
this remainder into a constant multiple of $(m/\ell)^2$.

Linearly interpolate the grid values. Within a grid cell an increment is a
fraction $\theta$ of the grid increment. Its fourth moment is at most
$C\theta^4/\ell^2\le C|u-v|^2$, since $\theta=\ell|u-v|\le1$.
Across cells split an interval into its first partial cell, full grid part,
and final partial cell. The inequality
$|x+y+z|^4\le27(|x|^4+|y|^4+|z|^4)$ gives the uniform continuity bound
$C|u-v|^2$. The same argument handles the final shorter cell by extending
the process constantly to the next mesh point before restricting back to
$[0,\alpha]$. The fourth-moment tightness criterion therefore applies to
the interpolated processes.

To compare with the original step processes, let $D_j$ count all cycles in
one logarithmic grid bin. Its harmonic intensity is bounded by an absolute
constant. The upper moment theorem at orders at most four gives
$\mathbb ED_j^4\le C$, uniformly over the bins. There are $O(\ell)$ bins, so
for every $\eta>0$,
\[
 \mathbb P\{\max_jD_j>\eta\sqrt\ell\}
 \le \frac{C}{\eta^4\ell}\longrightarrow0.
\]
Within a bin, the normalized log-product oscillation is at most a fixed
multiple of $D_j/\sqrt\ell$, because $\log r/\ell\le\alpha$. The deterministic
reference centerings have oscillation $O(1/\sqrt\ell)$ there. Thus both step
processes are uniformly close in probability to the tight interpolations.

'''+s[b:]
# Replace old validation section with appendix and current record.
s=s[:s.index('## 10. Finite checks actually executed')]
s+=r'''## Appendix A. Equality graphs for wrapped contexts

This appendix proves the small-length collision estimate used in (6.1).
Let $B$ require primitive component words and different necklaces for any
two components of the same length.

For two positions on the same circle of length $n$, with nonzero displacement
$a$, the $h$ consecutive comparisons are edges $t\leftrightarrow t+a$ modulo
$n$. Write $g=\gcd(n,a)$. For $h<n$, the omitted $n-h$ starting positions are
consecutive and meet $\min(g,n-h)$ of the $g$ cycles of the full shift graph.
The retained equality system therefore has rank
\[
 h-\max(0,g-n+h)=\min(h,n-g)
\]
over $\mathbb F_2$. The same formula holds for $h\ge n$, when the rank has
already saturated. If $h\ge n-g$, equality forces period dividing $g<n$,
which is impossible on $B$. Otherwise the rank is $h$, so equality has
probability $2^{-h}$. This includes a two-cycle in the shift graph: its two
oriented edges impose one linear relation.

For positions on different circles of lengths $r,s$, offset their roots so
that the comparisons are
$(t\bmod r)\leftrightarrow(t\bmod s)$, $0\le t<h$, in a bipartite graph.
Let $g=\gcd(r,s)$ and assume $r\le s$. Its first $s$ edges attach each
vertex of the second circle once. Contract those edges. The next $r-g$
edges become $j\leftrightarrow j+s\pmod r$, $0\le j<r-g$. The full
shift-by-$s$ graph has $g$ cycles, and the omitted $g$ consecutive edges
remove exactly one from each. Thus the first $r+s-g$ comparison edges form
a forest and have that rank. At this threshold both words are forced to
have period dividing $g$. This is excluded by $B$: either a component is
nonprimitive, or the two have equal length and represent the same necklace.
For smaller $h$ the comparisons have rank $h$ and probability $2^{-h}$.

Taking $h=d-1$ proves, for every pair of distinct positions,
\[
 \mathbb P\{B\text{ and their contexts agree}\}\le2^{-(d-1)}.
\]
On $B$ without such a collision, the weighted-word integrand equals one.
On valid words its maximum is
$2^m\le L^{L/(2d)}\le L^{2k}$ when every length is below $4d$.
The union bound over $\binom L2$ pairs gives (6.1).

## Appendix B. Review and computational record

The supplied source and its audit ZIP have been preserved byte-for-byte in
the accompanying archive. The reviewed version expands the marked
switching proof, the finite-measure likelihood normalization, the
small-length base, the asymptotic parameter calculation, the two-stage
induction, the bridge contact estimates, and the functional tightness
argument. No change to the stated range or normalization was needed.

Both supplied scripts were rerun. Their JSON outputs reproduced the supplied
JSON exactly. The rerun covers 272 complete feedback environments in dimensions
3 and 4 and seeded deterministic tests in 512 environments in dimensions
5 and 6. It reports 873 aggregate marked switching bounds, 175 partial-forcing
and open-collision bounds, 243,751 root identities, 9,998 convexity checks,
53,733 entropy/mixture checks, and 262 complete short-word type classes.
The bridge rerun reproduces 384 conditional marginal checks and 852 good
histories among 13,500 seeded reference samples.

A separately implemented atom-level audit exhausts every feedback table in
dimensions 2 through 5: 65,812 environments and 1,050,696 context flips. It
checks the actual feedback-bit flip, both split lengths, both orientations,
and preservation of every spectator cycle. There were 2,299,204 spectator
cycle preservation checks. A separate equality-graph audit verifies 174,720
same-circle ranks and 97,600 different-circle ranks, including overlap,
wraparound, equal lengths, and windows longer than their component words.
All executed assertions passed.

These computations verify finite ingredients only. They do not test the
asymptotic entropy tail at exponentially long lengths. That step is established
analytically in Section 3. This review found no unresolved mathematical gap
in the stated fixed-parameter range; it is not independent peer review or
proof-assistant certification. The separate audit report contains the full
dependency assessment and reproduction instructions.

## Context and references

The model is exactly the binary noncoalescing feedback permutation studied
by Arratia, Canfield, and Hales [ACH]. Their large-cycle theorem is a
Poisson–Dirichlet limit, and their paper explicitly distinguishes that
weak limit from local cycle-length asymptotics. It is not an input to the
present proof. The short-cycle literature includes Stark [Stark]. These
references give context; a comprehensive priority or novelty review has
not been completed here.

[ACH] R. A. Arratia, E. R. Canfield, and A. W. Hales, *Random Feedback Shift
Registers, and the Limit Distribution for Largest Cycle Lengths*,
arXiv:1903.09183, version 4, 2022, especially Sections 1–2.

[Stark] D. Stark, *The small cycle counts of random feedback shift registers*,
Australasian Journal of Combinatorics **86** (2023), 414–422.
'''
s=s.replace('The displayed polynomial is deliberately not optimized.', 'The displayed growth factor is deliberately not optimized.')
# Use math for raw prose identifiers without altering mathematical content.
# Pandoc's tex_math_single_backslash extension reads the existing display syntax.
(root/'release/thorp_alpha_lt_two_thirds.md').write_text(s)
print('wrote',root/'release/thorp_alpha_lt_two_thirds.md','chars',len(s),'lines',len(s.splitlines()))
