#!/usr/bin/env python3
"""Check frozen files. Additional rerun/rebuild output does not affect verification."""
from pathlib import Path
import hashlib
root=Path(__file__).resolve().parent
count=0
for line in (root/'SHA256SUMS').read_text().splitlines():
    digest,name=line.split('  ',1)
    p=(root/name).resolve()
    if not p.is_relative_to(root):raise RuntimeError('Manifest path escapes release root')
    if not p.is_file():raise FileNotFoundError(name)
    actual=hashlib.sha256(p.read_bytes()).hexdigest()
    if actual!=digest:raise RuntimeError(f'Checksum mismatch: {name}')
    count+=1
print(f'All {count} preserved files match SHA-256 checksums.')
