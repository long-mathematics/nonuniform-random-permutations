#!/usr/bin/env python3
"""Rerun checks without modifying frozen input files or frozen result JSON."""
from pathlib import Path
import json, subprocess, sys, shutil
ROOT=Path(__file__).resolve().parent
WORK=ROOT/'validation/rerun'
WORK.mkdir(parents=True,exist_ok=True)
report=[]
def run_json(cmd,path):
    p=subprocess.run(cmd,cwd=WORK,text=True,capture_output=True,check=True)
    path.write_text(p.stdout)
    if p.stderr:(path.with_suffix('.stderr.txt')).write_text(p.stderr)
    return json.loads(p.stdout)
for stem,expected in [
 ('thorp_multiscale_cycle_audit','multiscale_rerun.json'),
 ('thorp_multibridge_audit','multibridge_rerun.json')]:
    src=ROOT/'original/audit'/f'{stem}.py'
    text=src.read_text()
    text=text.replace('/mnt/data/',str(WORK)+'/')
    relocated=WORK/f'{stem}.py';relocated.write_text(text)
    got=run_json([sys.executable,str(relocated)],WORK/f'{stem}.stdout.json')
    wanted=json.loads((ROOT/'validation'/expected).read_text())
    if got!=wanted:raise AssertionError(f'{stem}: result differs from preserved run')
    report.append({'check':stem,'matches_preserved_result':True})
compiler=shutil.which('g++')
if not compiler:raise RuntimeError('g++ is required for the C++17 atom audit')
exe=WORK/'independent_switch_audit'
subprocess.run([compiler,'-O2','-std=c++17',str(ROOT/'validation/independent_switch_audit.cpp'),'-o',str(exe)],check=True)
got=run_json([str(exe)],WORK/'independent_switch_results.json')
assert got==json.loads((ROOT/'validation/independent_switch_results.json').read_text())
report.append({'check':'independent_switch_audit','matches_preserved_result':True})
got=run_json([sys.executable,str(ROOT/'validation/independent_overlap_rank_audit.py')],WORK/'independent_overlap_results.json')
assert got==json.loads((ROOT/'validation/independent_overlap_results.json').read_text())
report.append({'check':'independent_overlap_rank_audit','matches_preserved_result':True})
result={'status':'all reruns match preserved results','checks':report}
(WORK/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
