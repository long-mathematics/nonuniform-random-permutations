# Thorp alpha < 2/3: reviewed and preserved release

Version 1.0 — 9 October 2026

Start with `release/thorp_alpha_lt_two_thirds.pdf`. Editable sources are supplied
as both Markdown and standalone LaTeX. `AUDIT_REPORT.md` records exactly what
was reviewed, what was expanded, which tests were rerun, and the limitations
of validation.

## Result

For every fixed number of cycles, normalized joint factorial moments have the
uniform-permutation leading term, with a polynomial-in-d multiple of L/N error,
when all cycle lengths are at least 4d and their total L is at most N^beta,
for fixed beta<2/3. The uniform upper bound also includes shorter lengths.
There is no restriction on length ratios.

The truncated count/order functional Gaussian theorem holds on every fixed
[0,alpha], alpha<2/3. This is not the full permutation-order theorem and not a
claim at alpha=2/3.

## Archive layout

- `original/`: unchanged input manuscript, original audit ZIP and extracted
  contents, and the adjacent proof notes on which the working derivation arose.
- `release/`: reviewed manuscript in Markdown, LaTeX and PDF, with its LaTeX
  header. The manuscript gives the proof rather than relying on the older notes.
- `validation/`: build/expansion scripts, same-session rerun results, additional
  exact-audit implementations/results, environment record, and PDF build log.
- `AUDIT_REPORT.md`: proof-level assessment and explicit limits.
- `SHA256SUMS`: checksums for every preserved file other than the checksum file.
- `verify_manifest.py`: verify the preserved bytes.
- `reproduce.py`: rerun supplied checks in a separate output directory and rerun
  the additional atom/rank audits.

## Verify and rerun

Run from the archive root:

```sh
python3 verify_manifest.py
python3 reproduce.py
```

Python 3.10+ and a C++17 compiler (`g++`) suffice for the computations. The
scripts use only the Python/C++ standard libraries. The reproduction driver
relocates the supplied scripts' hard-coded output paths in temporary copies;
the archived originals are not edited. New results are written under
`validation/rerun/` and compared to the frozen JSON results.

To rebuild the PDF without overwriting the preserved PDF:

```sh
mkdir -p validation/rebuild
cp release/thorp_alpha_lt_two_thirds.tex validation/rebuild/
(cd validation/rebuild && latexmk -pdf -interaction=nonstopmode \
  -halt-on-error thorp_alpha_lt_two_thirds.tex)
```

A standard TeX Live installation with latexmk, amsmath, mathtools, microtype,
fancyhdr, and Latin Modern is sufficient. PDF metadata timestamps can differ
on a rebuild; source/test preservation is byte-checksummed, not a claim that
all future PDFs are byte-identical.

The reviewed Markdown can be regenerated from the original and the documented
expansion scripts by running `validation/build_reviewed_markdown.py` followed
by `validation/polish_release.py`. To convert an edited Markdown copy, use
Pandoc with `--from=markdown+tex_math_single_backslash`, `--standalone`, and
`--include-in-header=release/header.tex`.

## Validation meaning

The proof survived this same-assistant audit without a weakened range. This is
not independent peer review or formal kernel verification. Finite checks
support exact ingredients; they do not establish the asymptotic entropy tail.
No remote repository was modified by creation of this archive.
