# Proof audit: the alpha < 2/3 Thorp theorem

**Date:** 9 October 2026  
**Release:** 1.0, reviewed research proof  
**Source:** `original/thorp_multiscale_cycle_moments.md`  
**Reviewed text:** `release/thorp_alpha_lt_two_thirds.md` and the corresponding TeX/PDF

## Decision

I found no unresolved mathematical gap in the fixed-parameter alpha < 2/3
result after reconstructing its dependency chain. No weakening of the exponent,
normalization, or arbitrary-length-ratio conclusion was needed. The preserved
release expands several steps that were too compressed for a standalone proof,
and makes a final-grid-cell choice in the tightness argument explicit.

This is a same-assistant proof audit with separately implemented computational
checks. It is **not** independent peer review, a proof-assistant certificate,
or a claim that finite enumeration establishes the asymptotic theorem.

## Exactly what is retained

Let N=2^d, let the feedback table be chosen once with independent fair entries,
and let C_r count r-cycles of the resulting physical Thorp permutation. For
fixed k and 0<beta<2/3, put

\[
 Q_d(r_1,\ldots,r_k)=\left(\prod_i r_i\right)
 \mathbb E\prod_m(C_m)_{a_m},\qquad L=\sum_i r_i,
\]
\[
 p_\beta=\frac{2}{2-3\beta},\qquad
 P_{k,\beta}(d)=d^{4k+1}+d(d\log_2d)^{kp_\beta}.
\]

For sufficiently large d, all positive lengths with L<=N^beta satisfy

\[
 Q_d(\mathbf r)\le1+C_{k,\beta}P_{k,\beta}(d)L/N.
\]

When every r_i>=4d, the matching lower estimate is

\[
 Q_d(\mathbf r)\ge1-C_kdL/N.
\]

There is no comparability condition on the lengths. Repeated lengths use
falling factorials and therefore designate distinct cycles. Constants and the
large-d threshold may depend on k and beta. They are not uniform as k grows or
beta approaches 2/3.

For each fixed alpha<2/3, the joint cycle-count/logarithmic-LCM process has the
claimed Gaussian limit in D([0,alpha],R^2), with the J1 topology and a continuous
limit. In particular, the truncated order at b=floor(N^alpha) satisfies the
classical Erdos--Turan normalization at size b.

## Dependency audit

| Component | Review outcome and reason |
|---|---|
| Weighted cyclic-word identity | Re-derived. Distinct d-windows force every context to occur at most twice and make repeated feedback prescriptions consistent. Root factors and falling factorials agree. |
| Empirical type count | Re-derived for h<=n using the empirical Markov law; for h>n a supported h-block determines the entire necklace, so the same bound remains valid. |
| Mixture entropy | Re-derived as conditional mutual information: L delta_mix - sum r_i delta_i = L I(Y;J|X)>=0. No comparability or independence assumption on component words. |
| Dense entropy tail | Parameter calculation expanded. Positivity of (2d-3h)/h follows from fixed beta<2/3, and the geometric tail is bounded explicitly. This is an analytic proof, not a finite-size test. |
| Marked stopped switching | Atom-level injection written out. The first-return restriction is retained. The flipped context is unused by every previously marked cycle, which therefore survives with its root and weight unchanged. |
| Longest-last likelihood | Exact finite-measure calculation written out. Only the final cycle is forced; the earlier-cycle measure has mass Q_d(a), not one. Its unqueried feedback entries are sampled by deferred decisions after conditioning on recorded cycle histories. |
| Open-repeat accounting | J+K=m_new and the convexity inequality are checked per fixed family, averaging only the last root. The collision count is stopped before return or contact with a marked cycle. |
| Upper induction | Written as outer induction on fixed order and strong inner induction on total length. A crude 2^k bound is established first; only afterwards is the sharp constant recovered by removing longest components. The lower bound is not used. |
| Multicycle lower bridge | Probability and weight arguments separated. Middle-path intersections cost O((t_i+t_j+1)/N), not O(t_i t_j/N). Self-contacts use a single-middle marginal first-contact coupling; other-middle contacts use conditional uniform marginals and independent roots. No joint endpoint independence given all traces is asserted. |
| Moment transfer | Uniform factorial-moment error is exponentially small in d for each fixed order, so every polynomial-in-log-N expansion loss is negligible. The auxiliary beta is chosen strictly above alpha. |
| Tightness | Expanded fourth-moment comparison, interpolation, and maximum-bin argument. The process is extended constantly to a full mesh point past alpha before interpolation; this avoids making an unjustified uniform claim on an arbitrarily shortened final cell. |
| Product-to-LCM | Exact von Mangoldt identity plus uniform order-one and order-two upper bounds. Endpoint expectation controls the entire truncated path because the discrepancy is nondecreasing. |

The resulting dependency chain is:

weighted words -> entropy tail;
marked stopped switching -> open-collision bounds;
these two + longest-last forcing -> upper moments;
upper moments of order one -> terminal smoothing -> multicycle lower bridge;
upper and lower moments -> finite-dimensional Gaussian limits + tightness;
harmonic first/two-cycle bounds -> product-to-LCM transfer.

This ordering has no circular lower-to-upper bootstrap.

## Changes from the supplied manuscript

The original manuscript is preserved byte-for-byte. The reviewed version does
not silently replace the model or import a stronger external theorem.

The substantive additions are the explicit marked injection and its scaling,
the successful-history likelihood calculation, the wrapped equality-graph
proof for the short base, the parameter calculation for the sparse threshold,
the crude-then-sharp induction, and the full fourth-moment tightness argument.
The bridge proof is reorganized so that self-contacts and contacts with other
middles use different, justified probability comparisons. The topology and
fixed-parameter quantifiers are stated at the start. Notation is typeset
consistently, including empty-LCM and repeated-cycle conventions.

No hypothesis was added to the main theorem, and no claimed exponent was
changed. The existing comparable-length proof and protected-cut arguments are
not required by this self-contained release.

## Reproduced computations

Both scripts in the supplied audit ZIP were rerun without changing the
preserved scripts. Their JSON output matched the supplied JSON exactly.

The multiscale run includes 272 exhaustively enumerated feedback environments
in dimensions 3 and 4, 512 seeded environments in dimensions 5 and 6 for
deterministic checks, 873 aggregate marked switching bounds, 175 partial-forcing
and open-collision bounds, 243,751 root identities, 9,998 convexity checks,
53,733 entropy/mixture checks, and 262 short-component type classes.

The bridge run reproduces 384 conditional bridge-context marginal checks and
852 good histories among 13,500 seeded reference samples. The good-history
sample is not an estimate used in the asymptotic proof.

## Additional implementations in this audit

`validation/independent_switch_audit.cpp` exhausts every feedback table in
dimensions 2 through 5. It checks 65,812 environments, 1,050,696 context flips,
the two oriented split/join descriptions, and 2,299,204 spectator-cycle
preservation statements. All assertions passed.

`validation/independent_overlap_rank_audit.py` checks exact equality-constraint
ranks in 174,720 same-circle and 97,600 different-circle cases. This includes
overlap, wraparound, equal lengths, and component periods shorter than the
window. All assertions passed.

The separate implementations are not separate mathematical reviewers. None of
these tests reaches the exponentially long asymptotic regime of the theorem.

## Rendering and source preservation

The reviewed Markdown was converted to standalone LaTeX, compiled to a
15-page PDF, and rendered page by page for visual inspection. The final build
has no LaTeX errors, overfull boxes, or unresolved references. Source originals,
reviewed sources, test implementations, test outputs, and instructions are
included in the archive. `SHA256SUMS` identifies the frozen bytes.

The release deliberately contains no font files and no executable binaries.

## What this does not validate

The full one-shuffle order theorem, the endpoint alpha=2/3, any range beyond
2/3, moment orders increasing with d, deterministic-seed local limit statements,
or a growing-dimensional Poisson total-variation approximation beyond the
birthday scale are not proved here. The proof still loses its dense-tail
saving when the entropy coefficient 2d-3h ceases to be positive.

A comprehensive novelty review is also separate. The contextual comparison
with Arratia--Canfield--Hales was checked against arXiv:1903.09183v4, Sections
1--2 (including its distinction between the macroscopic limit and local cycle
asymptotics). Their theorem is not a proof dependency of this release.
